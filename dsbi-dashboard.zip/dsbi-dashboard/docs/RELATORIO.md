# Relatório do Projeto — DSBI (Data & Business Intelligence)

> **Dados simulados.** "Vertix Distribuidora" é fictícia. Todos os números vêm de uma base gerada com semente fixa, com padrões plantados de propósito e documentados. O método vale para dados reais; os resultados, não.

## Resumo

O projeto responde: **como transformar dados dispersos em indicadores que ajudem gestores a tomar decisões?** A resposta construída foi uma cadeia curta e testada: banco SQLite, views SQL que calculam os indicadores, um cubo mensal de somas e um painel React que, além dos gráficos, entrega **7 cartões de decisão**, cada um com gatilho, evidência, ação, dono, prazo e quando revisar.

- **Base:** 31.007 pedidos, 97.843 itens, R$ 217,3 mi, 620 clientes e 12 vendedores, de jan/2024 a set/2026.
- **Painel:** 5 páginas (Visão executiva, Comercial, Operações, Decisões, Metodologia) em um único arquivo HTML que abre offline.
- **Decisões:** 3 "Agir agora", 2 "Investigar", 1 "Planejar" e 1 "Monitorar". Nem todo alerta pede ação.
- **Qualidade:** 10 controles de erro, todos em zero; testes automáticos conferem totais do cubo contra o SQL e cada história plantada.

## Passo a passo do projeto

![Pipeline do projeto](diagrama_pipeline.png)

1. **Dados:** `gerar_dados.py` cria o banco com regras de negócio realistas (sazonalidade, cadastros, descontos, devoluções, chamados, estoque) e o plano de orçamento e forecast.
2. **SQL:** `sql/01` a `04` criam tabelas, a view do cubo, os KPIs, as views de decisão e os controles de qualidade.
3. **Cubo:** `exportar_json.py` lê as views e grava um JSON com somas por mês × região × linha × segmento. O painel filtra e recalcula razões (margem, OTD) sem médias de médias.
4. **Decisão:** os gatilhos vêm da tabela `parametros`. Cada cartão traz evidência, hipóteses alternativas, impacto *Observado* ou *Estimado* e premissa escrita.
5. **Painel e entrega:** React, Recharts (linhas, barras, dispersão) e D3 (cascata e mapa de calor). Testes, relatório e PDF fecham o ciclo.

## Os indicadores

| Indicador | Definição |
|---|---|
| Receita | valor líquido (após desconto) dos pedidos não cancelados, no mês do pedido |
| Margem bruta % | 1 − custo / receita |
| Desconto % | 1 − receita / valor a preço de lista |
| OTD | entregues na data prometida ou antes / entregues |
| Devolução % | valor devolvido / receita |
| Ticket médio | receita / pedidos não cancelados |

Em 2026 (até set): receita R$ 62,0 mi (−2,1% vs orçado, −0,3% vs forecast, +7,7% vs 2025), margem 21,9% (−1,9 pp vs orçado), OTD 90,5% (meta 92%) e ticket médio R$ 7.080. Os valores do painel foram conferidos contra as views SQL.

## Do indicador à decisão

| # | Decisão | Status | O que dispara | Impacto |
|---|---|---|---|---|
| D1 | Clientes que pararam de comprar | Agir agora | 53 clientes em risco, R$ 11,7 mi (13,4% da receita 12m); 70% concentrados na carteira de V04, que saiu em 15/05/2026 | Estimado: R$ 2,61 mi de margem por ano |
| D2 | Margem de Eletrônicos | Agir agora | margem 9,5% (era 14,1%) com desconto de 8,5% → 13,4% | Observado: R$ 0,64 mi em 6 meses |
| D4 | Rupturas de estoque | Agir agora | 6 produtos com ≥ 5 dias sem estoque no trimestre | Estimado: R$ 0,27 mi de margem |
| D5 | Desconto de vendedores | Investigar | V03 (13,2%) e V09 (11,5%) contra ~7% dos pares da região | Estimado: R$ 0,52 mi em 6 meses |
| D3 | Entregas no Nordeste | Investigar | OTD 75,2% (era 86,1%); atraso gera 3,9× mais devolução | Estimado: só custo direto medido |
| D7 | Pico de nov/dez | Planejar | índice 1,24 e 1,38, repetido em 2024 e 2025 | sem valor calculado |
| D6 | Dependência de grandes clientes | Monitorar | top 10 = 11,2% da receita, gatilho de 25% | sem ação |

Dois cuidados deixam o painel honesto: cada cartão separa **evidência** de **hipótese** (por exemplo, a saída de V04 é associação forte, mas a causa precisa ser confirmada com os clientes) e cada impacto diz se é **Observado** ou **Estimado** e qual premissa o sustenta.

## Problemas reais resolvidos

| # | Problema | Solução adotada | Resultado |
|---|---|---|---|
| 1 | Clientes ativos são contagem distinta e não podem ser somados entre meses ou linhas | Tabela própria `ativos` por mês × região × segmento; o painel avisa que não responde ao filtro de linha | Contagem correta, sem inflar |
| 2 | Média de médias distorce margem e OTD ao filtrar | Cubo só com somas; razões calculadas na hora | Margem e OTD batem com o SQL em qualquer filtro |
| 3 | Clientes perdidos há muito tempo poluíam "em risco" | Janela de 90 a 365 dias, com 3× o intervalo habitual e mínimo de 4 pedidos | Lista só de quem ainda dá para recuperar |
| 4 | Gatilhos faltando e espalhados no código | Todos em `parametros` (`risco_dias_max`, `gatilho_risco_pct` etc.) | Mudar um limite muda o alerta |
| 5 | Atraso de entrega com custo direto baixo virava "Agir agora" | Regra de status: só "Agir agora" se custo × margem ≥ R$ 100 mil | D3 ficou em "Investigar" |
| 6 | Ruído normal de carteira parecia problema em todos os vendedores | Cartão compara V04 com os demais (23 clientes = ruído esperado) | Concentração em V04 fica evidente |
| 7 | Ano em curso comparado com ano fechado | Comparação com o mesmo período (jan–set × jan–set) | Crescimento de +7,7% justo |
| 8 | Gráficos saíam vazios na captura de tela | Animação do Recharts reiniciava no redimensionamento; desligada | Capturas e PDF corretos |
| 9 | Top 10 de clientes mostrava 15 | Corte em 10 antes de somar | 11,2% no gráfico e no cartão D6 |
| 10 | Tabela de rupturas formatava valor em % | Colunas de valor formatadas como R$ | Leitura correta |
| 11 | Cascata com eixo cortado exagera diferenças | Eixo começa acima de zero e o gráfico avisa o valor inicial | Variações visíveis sem esconder a escala |
| 12 | Cores no tema escuro | Paleta validada (luminosidade, croma, daltonismo, contraste); legenda e rótulo como apoio | Todos os testes de cor passam |

## Validação

- `testes.py` confere integridade, totais do cubo contra as views, cobertura do plano, as seis histórias plantadas (H1–H6), o controle de concentração e que todo cartão tem dono, prazo, acompanhamento e gatilho de revisão. Resultado: **TUDO CERTO**.
- `vw_qualidade`: 10 verificações de erro em 0; 5 informativas (154 pedidos em trânsito, 476 cancelados, 1 cliente sem pedido, 64 clientes em carteira de vendedor inativo).
- Valores dos KPIs do painel (2026) conferidos contra o SQL: receita R$ 61.983.927, margem 21,87%, OTD 90,55%, ticket R$ 7.079,83.
- Não foi feito teste automatizado da interface; a conferência visual usou capturas do navegador sem erros no console.

## Limites

- Dados simulados: o projeto prova o método, não um resultado real.
- Impactos "Estimado" dependem de premissas (ex.: recuperar 30% dos clientes em risco).
- Associação não é causa; cada cartão lista o que falta confirmar.
- Orçado e forecast são simulados e só existem por mês × região × linha; margem e OTD têm meta, não orçamento por segmento.

## Próximos passos

1. Trocar a base simulada por dados reais mantendo o esquema.
2. Calibrar gatilhos com quem conhece a operação.
3. Medir se as ações recomendadas mudaram o indicador (fechar o ciclo da decisão).
