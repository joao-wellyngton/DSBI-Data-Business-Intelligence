"""Roda a cadeia inteira: dados -> SQL -> JSON -> testes -> painel (Vite).
Uso: python src/build_dsbi.py   (precisa de Python 3 com pandas/numpy e Node 18+)"""
import subprocess, sys
from pathlib import Path
raiz = Path(__file__).resolve().parent.parent
def run(cmd, cwd=raiz):
    print("->", " ".join(cmd)); subprocess.run(cmd, cwd=cwd, check=True)
run([sys.executable, "-I", "src/gerar_dados.py"])
run([sys.executable, "-I", "src/exportar_json.py"])
run([sys.executable, "-I", "src/testes.py"])
if not (raiz / "app" / "node_modules").exists():
    run(["npm", "install"], cwd=raiz / "app")
run(["npm", "run", "build"], cwd=raiz / "app")
print("Pronto: abra dashboard/index.html")
