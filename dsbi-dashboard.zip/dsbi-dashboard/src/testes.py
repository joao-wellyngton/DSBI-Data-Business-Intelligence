#!/usr/bin/env python3
"""
Testes do pipeline. Rodar depois de gerar_dados.py e exportar_json.py:  python src/testes.py

1. Integridade: todas as verificações 'erro' de vw_qualidade devem ser 0
2. Consistência: cubo exportado reproduz os totais do SQL (receita, margem, pedidos, OTD)
3. Orçamento: plano_mensal cobre todas as células com venda
4. Histórias plantadas: os sinais e as decisões aparecem como esperado
"""
import json
import sqlite3
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
con = sqlite3.connect(RAIZ / "data" / "dsbi.db")
d = json.loads((RAIZ / "app" / "src" / "data.json").read_text(encoding="utf-8"))
falhas = []
def ok(nome, cond, det=""):
    print(("OK   " if cond else "FALHA"), nome, det)
    if not cond:
        falhas.append(nome)

# 1 integridade
for v, sev, qtd in con.execute("SELECT * FROM vw_qualidade"):
    if sev == "erro":
        ok(f"integridade: {v}", qtd == 0, f"({qtd})")

# 2 consistência cubo JSON x SQL direto (sem passar pelas views do cubo)
rec_sql, cus_sql, ped_sql, ent_sql, np_sql = con.execute("""
    SELECT SUM(CASE WHEN status<>'cancelado' THEN valor_liquido END), SUM(CASE WHEN status<>'cancelado' THEN custo_total END),
           SUM(status<>'cancelado'), SUM(status='entregue'), SUM(status='entregue' AND data_entrega<=data_prometida) FROM pedidos""").fetchone()
cub = d["cubo"]
ok("cubo: receita total", abs(sum(r["rec"] for r in cub) - rec_sql) < 1, f"{rec_sql:,.0f}")
ok("cubo: custo total", abs(sum(r["cus"] for r in cub) - cus_sql) < 1)
ok("cubo: pedidos", sum(r["ped"] for r in cub) == ped_sql, str(ped_sql))
ok("cubo: OTD", abs(100 * sum(r["np"] for r in cub) / sum(r["ent"] for r in cub) - 100 * np_sql / ent_sql) < 1e-9)
dev_sql = con.execute("SELECT SUM(valor) FROM devolucoes").fetchone()[0]
ok("cubo: devoluções", abs(sum(r["dev"] for r in cub) - dev_sql) < 1)
ok("cubo: chamados", sum(r["ch"] for r in cub) == con.execute("SELECT COUNT(*) FROM chamados").fetchone()[0])
ano = con.execute("SELECT SUM(valor_liquido) FROM pedidos WHERE status<>'cancelado' AND data_pedido LIKE '2025-%'").fetchone()[0]
ok("cubo: receita 2025", abs(sum(r["rec"] for r in cub if r["m"].startswith("2025")) - ano) < 1)

# 3 plano
celulas = {(r["m"], r["r"], r["l"]) for r in cub}
plano = {(p["m"], p["r"], p["l"]) for p in d["plano"]}
ok("plano cobre todas as células com venda", celulas == plano, f"{len(celulas)} células")

# 4 histórias plantadas
dec = {x["id"]: x for x in d["decisoes"]}
ok("H1 margem: Eletrônicos aciona D2 (Forte)", "D2" in dec and dec["D2"]["evidencia"]["nivel"] == "Forte")
mg = {r["linha"]: r for r in con.execute("SELECT linha, janela, margem_pct FROM vw_margem_linha").fetchall() and
      [dict(linha=a, janela=b, m=c) for a, b, c in con.execute("SELECT linha, janela, margem_pct FROM vw_margem_linha") if b == "atual"]}
ok("H1 margem: só Eletrônicos aciona", sum(1 for x in d["decisoes"] if x["id"] == "D2") == 1 and "Eletrônicos" in dec["D2"]["titulo"])
otd = {r[0]: r[1] for r in con.execute("SELECT regiao, otd_pct FROM vw_otd_regiao WHERE janela='atual'")}
ok("H2 OTD: Nordeste abaixo de 80% e é a única região em queda", otd["Nordeste"] < 80 and "D3" in dec and "Nordeste" in dec["D3"]["titulo"], f"{otd['Nordeste']:.1f}%")
risco = con.execute("SELECT vendedor_id, COUNT(*) FROM vw_clientes_risco GROUP BY 1 ORDER BY 2 DESC").fetchall()
ok("H3 churn: V04 lidera clientes em risco com >= 25", risco[0][0] == "V04" and risco[0][1] >= 25, str(risco[:3]))
ok("H3 churn: D1 aciona 'Agir agora'", dec["D1"]["status"] == "Agir agora")
rup = con.execute("SELECT COUNT(*) FROM vw_ruptura WHERE ruptura_dias>=5").fetchone()[0]
ok("H4 ruptura: exatamente 6 produtos acima do gatilho", rup == 6, str(rup))
z = {r[0]: r[1] for r in con.execute("SELECT vendedor_id, z FROM vw_vendedor_desconto")}
ok("H5 desconto: V03 e V09 são os únicos com z >= 1,5", {k for k, v in z.items() if v >= 1.5} == {"V03", "V09"}, str({k: round(v, 2) for k, v in z.items() if v > 1}))
saz = {r[0]: r[1] for r in con.execute("SELECT mes, indice FROM vw_sazonalidade")}
ok("H6 sazonalidade: dez > 1,2 e jan < 0,85", saz[12] > 1.2 and saz[1] < .85)
ok("controle: concentração NÃO aciona (top 10 < 25%)", dec["D6"]["status"] == "Monitorar")
ok("impacto rotulado como Observado ou Estimado", all(x["impacto"]["tipo"] in ("Observado", "Estimado") for x in d["decisoes"]))
ok("toda decisão tem dono, prazo, acompanhamento e gatilho de revisão", all(x["responsavel"] and x["prazo"] and x["acompanhar"] and x["revisar_se"] for x in d["decisoes"]))
print("\n" + ("TUDO CERTO" if not falhas else f"{len(falhas)} FALHA(S): {falhas}"))
sys.exit(1 if falhas else 0)
