"""Gera docs/Relatorio_DSBI.pdf a partir de docs/RELATORIO.md (precisa de markdown e playwright)."""
import re
from pathlib import Path
import markdown
from playwright.sync_api import sync_playwright
raiz = Path(__file__).resolve().parent.parent
md = (raiz / "docs" / "RELATORIO.md").read_text(encoding="utf-8")
md = md.split("\n", 1)[1]  # título vai na capa
corpo = markdown.markdown(md, extensions=["tables"])
corpo = corpo.replace('<img alt="Pipeline do projeto" src="diagrama_pipeline.png" />', '<div class="fig"><img src="diagrama_pipeline.png"></div>')
corpo = re.sub(r"<blockquote>\s*<p>", '<div class="warn"><p>', corpo).replace("</p>\n</blockquote>", "</p></div>")
css = """
@page{size:A4;margin:18mm 16mm}
:root{--b:#1f5fbf;--bs:#dce8fa;--ink:#0f1b33;--mut:#55627f;--line:#d6deee}
body{margin:0;font:10pt/1.5 Inter,'Helvetica Neue',Arial,sans-serif;color:var(--ink)}
.cover{height:297mm;margin:-18mm -16mm 0;padding:26mm 22mm;background:#1b2a4a;color:#fff;display:flex;flex-direction:column;justify-content:space-between;page-break-after:always;box-sizing:border-box}
.cover .tag{font-size:9pt;letter-spacing:.14em;text-transform:uppercase;opacity:.8}
.cover h1{font-size:34pt;line-height:1.1;margin:10mm 0 6mm}.cover p{font-size:13pt;max-width:140mm;opacity:.92;margin:0}
.kp{display:flex;gap:4mm}.kp div{background:rgba(255,255,255,.12);border-radius:4mm;padding:4mm 5mm;white-space:nowrap}.kp b{display:block;font-size:16pt}.kp span{font-size:8.5pt;opacity:.85}
h2{font-size:16pt;color:var(--b);margin:8mm 0 3mm;padding-bottom:2mm;border-bottom:2px solid var(--bs);page-break-after:avoid}
p{margin:0 0 3mm}ul,ol{margin:0 0 3mm;padding-left:5mm}li{margin-bottom:1mm}
table{width:100%;border-collapse:collapse;font-size:8.4pt;margin:2mm 0 4mm}
th{background:var(--bs);color:var(--b);text-align:left;padding:2mm;border-bottom:1.5px solid var(--b)}
td{padding:1.8mm 2mm;border-bottom:1px solid var(--line);vertical-align:top}tr{page-break-inside:avoid}
.fig img{width:100%;border:1px solid var(--line);border-radius:2mm}
.warn{background:#fff3cd;border:1px solid #e6c65c;color:#5c4400;border-radius:3mm;padding:3mm 4mm;font-size:9pt;margin-bottom:5mm}.warn p{margin:0}
code{background:#eef2fa;padding:0 1mm;border-radius:1mm;font-size:8.4pt}
"""
capa = """<section class='cover'><div><div class='tag'>Relatório de projeto · Business Intelligence</div>
<h1>DSBI — Data &amp; Business Intelligence</h1>
<p>Como transformar dados dispersos em indicadores que ajudem gestores a tomar decisões.</p></div>
<div class='kp'><div><b>31.007</b><span>pedidos</span></div><div><b>R$ 217,3 mi</b><span>receita simulada</span></div><div><b>7</b><span>cartões de decisão</span></div><div><b>0</b><span>erros de qualidade</span></div></div>
<div><b>Niel Hart · Studio Hart</b><br>SQL · SQLite · React · Recharts · D3<br>13 de outubro de 2026 · Dados simulados</div></section>"""
html = f"<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><title>Relatório DSBI</title><style>{css}</style></head><body>{capa}{corpo}</body></html>"
h = raiz / "docs" / "_relatorio.html"
h.write_text(html, encoding="utf-8")
with sync_playwright() as pw:
    b = pw.chromium.launch(); pg = b.new_page(); pg.goto(h.as_uri()); pg.wait_for_timeout(500)
    pg.pdf(path=str(raiz / "docs" / "Relatorio_DSBI.pdf"), format="A4", print_background=True, prefer_css_page_size=True,
           display_header_footer=True, header_template="<span></span>",
           footer_template="<div style='font:8pt Arial;color:#55627f;width:100%;text-align:center'>Relatório DSBI · Studio Hart · página <span class='pageNumber'></span> de <span class='totalPages'></span></div>",
           margin={"top": "18mm", "bottom": "18mm", "left": "16mm", "right": "16mm"})
    b.close()
h.unlink()
print("PDF gerado")
