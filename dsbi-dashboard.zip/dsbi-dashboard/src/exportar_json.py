#!/usr/bin/env python3
"""
Executa as views SQL (02, 03, 04) sobre data/dsbi.db e exporta app/src/data.json para o app React.

Princípio do projeto: indicador sem decisão é enfeite. Cada sinal vira um cartão de decisão com
indicador, gatilho, evidência, hipóteses alternativas, ação, dono, prazo, impacto e gatilho de revisão.
Impacto é sempre rotulado como OBSERVADO (medido) ou ESTIMADO (depende de premissa explícita).

Uso:  python src/exportar_json.py
"""
import json
import sqlite3
from datetime import datetime
from pathlib import Path

import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
DB = RAIZ / "data" / "dsbi.db"
SAIDA = RAIZ / "app" / "src" / "data.json"


def pt(x, d=1):
    s = f"{x:,.{d}f}"
    return s.replace(",", "§").replace(".", ",").replace("§", ".")


def mi(x, d=2):
    return f"R$ {pt(x / 1e6, d)} mi"


def mil(x):
    return f"R$ {pt(x / 1e3, 0)} mil"


def brl(x):
    return mi(x) if abs(x) >= 1e6 else mil(x)


def main():
    con = sqlite3.connect(DB)
    for f in ("02_kpis", "03_decisoes", "04_qualidade"):
        con.executescript((RAIZ / "sql" / f"{f}.sql").read_text(encoding="utf-8"))
    q = lambda sql: pd.read_sql_query(sql, con)
    par = dict(con.execute("SELECT chave, valor FROM parametros").fetchall())
    P = lambda k: float(par[k])

    cubo = q("SELECT * FROM vw_cubo_mensal ORDER BY ano_mes, regiao, linha, segmento")
    plano = q("SELECT * FROM plano_mensal ORDER BY ano_mes, regiao, linha")
    ativos = q("SELECT * FROM vw_ativos_mensal ORDER BY ano_mes, regiao, segmento")

    # ---------------------------------------------------------------- contexto global
    ttm = q("""SELECT SUM(valor_liquido) rec, SUM(custo_total) cus FROM pedidos
               WHERE status<>'cancelado' AND data_pedido > date((SELECT valor FROM parametros WHERE chave='as_of'),'-12 months')""").iloc[0]
    margem_ttm = 1 - ttm.cus / ttm.rec

    decisoes = []

    # ---------------------------------------------------------------- D1 clientes em risco
    risco = q("SELECT * FROM vw_clientes_risco ORDER BY receita_12m_antes DESC")
    conc = q("SELECT * FROM vw_concentracao_clientes ORDER BY rk")
    total_ttm = float(ttm.rec)
    rec_risco = float(risco.receita_12m_antes.sum())
    pct_risco = 100 * rec_risco / total_ttm
    por_v = risco.groupby(["vendedor_id", "vendedor", "vendedor_ativo"]).agg(n=("cliente_id", "count"), rec=("receita_12m_antes", "sum")).reset_index().sort_values("rec", ascending=False)
    topv = por_v.iloc[0]
    cart = q("""SELECT vendedor_id, COUNT(DISTINCT cliente_id) n FROM pedidos
                WHERE status<>'cancelado' AND data_pedido > date((SELECT valor FROM parametros WHERE chave='as_of'),'-24 months') GROUP BY 1""")
    part_cart = 100 * float(cart[cart.vendedor_id == topv.vendedor_id].n.iloc[0]) / float(cart.n.sum())
    part_risco = 100 * float(topv.rec) / rec_risco
    outros_n = int(len(risco) - topv.n)
    ouro_prata = int(risco.tier.isin(["Ouro", "Prata"]).sum())
    recup = rec_risco * P("premissa_recuperacao")
    forte = part_risco >= 40 and part_risco > 2 * part_cart
    decisoes.append(dict(
        id="D1", area="Comercial", status="Agir agora" if pct_risco >= P("gatilho_risco_pct") else "Monitorar",
        titulo="Clientes que pararam de comprar",
        pergunta="Quais clientes procurar primeiro e quem cuida deles agora?",
        indicador=dict(nome="Receita em risco", valor=f"{mi(rec_risco, 1)} · {pt(pct_risco)}% da receita 12m", gatilho=f"Dispara com ≥ {pt(P('gatilho_risco_pct'), 0)}% da receita 12m",
                       leitura=f"{len(risco)} clientes estão sem comprar há mais de 90 dias ou 3× o intervalo habitual deles."),
        sinais=[dict(r="Clientes em risco", v=f"{len(risco)} ({ouro_prata} Ouro/Prata)"),
                dict(r=f"Concentrados em {topv.vendedor_id}", v=f"{pt(part_risco, 0)}% da receita em risco"),
                dict(r=f"Peso de {topv.vendedor_id} na carteira", v=f"{pt(part_cart, 0)}% dos clientes"),
                dict(r="Demais vendedores", v=f"{outros_n} clientes (ruído normal de carteira)")],
        evidencia=dict(nivel="Forte" if forte else "Moderada",
                       porque=f"{topv.vendedor_id} tem {pt(part_cart, 0)}% da carteira e {pt(part_risco, 0)}% da receita em risco" +
                              (", e saiu da empresa em 15/05/2026. A associação é forte; a causa (saída do vendedor) ainda precisa ser confirmada com os clientes." if int(topv.vendedor_ativo) == 0 else ".")),
        alternativas=["Perda para concorrente (preço ou prazo)", "Cliente comprando por outro canal ou distribuidor", "Compra sazonal que atrasou"],
        acao=f"Reatribuir a carteira de {topv.vendedor_id} a gerentes de conta e contatar os {int(topv.n)} clientes em até 15 dias, começando por Ouro e Prata, do maior para o menor.",
        responsavel="Diretor Comercial e Gerente Regional Sudeste", prazo="15 dias",
        impacto=dict(rotulo="Margem bruta em jogo", valor=round(rec_risco * margem_ttm, 2), tipo="Estimado",
                     texto=f"{mi(rec_risco, 1)} de receita × margem de {pt(100 * margem_ttm)}% = {mi(rec_risco * margem_ttm, 2)} por ano",
                     premissa=f"Receita em risco = vendas dos 12 meses antes da parada de cada cliente. Com recuperação de {pt(100 * P('premissa_recuperacao'), 0)}% (premissa), voltam {mi(recup, 1)} de receita."),
        acompanhar="Clientes reativados (nova compra em 30 dias) e receita recuperada contra a premissa",
        revisar_se="Se menos de 10% reativarem em 60 dias, a causa não é relacionamento: investigar preço e concorrência.",
        tabela=dict(colunas=["Cliente", "Tier", "Região", "Vendedor", "Dias sem comprar", "Receita 12m antes"],
                    linhas=[[r.nome, r.tier, r.regiao, r.vendedor_id, int(r.dias_sem_compra), round(float(r.receita_12m_antes))] for r in risco.head(12).itertuples()])))

    # ---------------------------------------------------------------- D2 margem e desconto
    ml = q("SELECT * FROM vw_margem_linha")
    piv = ml.pivot(index="linha", columns="janela")
    linhas_alerta = []
    for ln in piv.index:
        d_m = piv.loc[ln, ("margem_pct", "atual")] - piv.loc[ln, ("margem_pct", "anterior")]
        if d_m <= -P("gatilho_margem_pp"):
            linhas_alerta.append(ln)
    resumo_margem = [dict(linha=ln, margem_ant=round(float(piv.loc[ln, ("margem_pct", "anterior")]), 2), margem_atu=round(float(piv.loc[ln, ("margem_pct", "atual")]), 2),
                          desc_ant=round(float(piv.loc[ln, ("desconto_pct", "anterior")]), 2), desc_atu=round(float(piv.loc[ln, ("desconto_pct", "atual")]), 2)) for ln in piv.index]
    if linhas_alerta:
        ln = linhas_alerta[0]
        r = lambda c, j: float(piv.loc[ln, (c, j)])
        pre = q(f"""SELECT 100.0*(1-SUM(custo)/SUM(receita)) m FROM vw_cubo_mensal WHERE linha='{ln}' AND ano_mes BETWEEN '2025-04' AND '2025-09'""").m.iloc[0]
        perda_mg = r("receita", "atual") * (r("margem_pct", "anterior") - r("margem_pct", "atual")) / 100
        d_ped = 100 * (r("pedidos", "atual") / r("pedidos", "anterior") - 1)
        forte = abs(r("margem_lista_pct", "atual") - r("margem_lista_pct", "anterior")) < 1 and (r("desconto_pct", "atual") - r("desconto_pct", "anterior")) >= 3
        decisoes.append(dict(
            id="D2", area="Comercial", status="Agir agora", titulo=f"Margem de {ln} em queda por desconto",
            pergunta="Quanto desconto podemos dar sem destruir margem?",
            indicador=dict(nome=f"Margem bruta de {ln}", valor=f"{pt(r('margem_pct', 'atual'))}% (era {pt(r('margem_pct', 'anterior'))}%)",
                           gatilho=f"Dispara com queda ≥ {pt(P('gatilho_margem_pp'), 0)} p.p. em 6 meses", leitura=f"Queda de {pt(r('margem_pct', 'anterior') - r('margem_pct', 'atual'))} p.p.; antes do aumento de desconto (abr-set/2025) a margem era {pt(pre)}%."),
            sinais=[dict(r="Desconto médio", v=f"{pt(r('desconto_pct', 'anterior'))}% → {pt(r('desconto_pct', 'atual'))}%"),
                    dict(r="Margem a preço de lista", v=f"{pt(r('margem_lista_pct', 'anterior'))}% → {pt(r('margem_lista_pct', 'atual'))}% (estável)"),
                    dict(r="Pedidos", v=f"{'+' if d_ped >= 0 else ''}{pt(d_ped)}% no período"),
                    dict(r="Outras linhas", v="margem estável (variação < 1 p.p.)")],
            evidencia=dict(nivel="Forte" if forte else "Moderada",
                           porque="A margem a preço de lista ficou estável, então custo e mix de produtos não explicam a queda. O desconto subiu mês a mês e o volume subiu pouco." if forte else "Desconto subiu, mas outros fatores não foram descartados."),
            alternativas=["Desconto como resposta a concorrente (confirmar com vendas)", "Mudança de mix entre clientes grandes e pequenos", "Promoção pontual que virou padrão"],
            acao=f"Definir teto de desconto por tier e alçada de aprovação acima do teto em {ln}; rever a tabela de preços. Os valores iniciais do teto devem ser calibrados com o histórico de 2025.",
            responsavel="Diretor Comercial e Gerente de Produto", prazo="30 dias",
            impacto=dict(rotulo="Margem bruta em jogo", valor=round(perda_mg, 2), tipo="Observado",
                         texto=f"{mi(perda_mg, 2)} de margem a menos nos últimos 6 meses, em relação à margem dos 6 meses anteriores",
                         premissa="Receita dos últimos 6 meses × queda de margem em relação ao semestre anterior. Sem premissa de recuperação."),
            acompanhar=f"Margem de {ln} por mês contra a orçada; desconto médio; nº de pedidos",
            revisar_se="Se os pedidos caírem mais de 5% em 60 dias depois do teto, testar um teto intermediário (a demanda é mais sensível ao preço do que o histórico mostra).",
            tabela=dict(colunas=["Linha", "Margem anterior %", "Margem atual %", "Desconto anterior %", "Desconto atual %"],
                        linhas=[[x["linha"], x["margem_ant"], x["margem_atu"], x["desc_ant"], x["desc_atu"]] for x in resumo_margem])))

    # ---------------------------------------------------------------- D4 ruptura de estoque
    rup = q("SELECT * FROM vw_ruptura WHERE ruptura_dias >= %s ORDER BY perda_estimada DESC" % int(P("gatilho_ruptura_dias")))
    if len(rup):
        perda_est = float(rup.perda_estimada.sum()); queda = float(rup.queda_observada.clip(lower=0).sum())
        mg_unit = float((rup.perda_estimada * rup.margem_unit_pct).sum() / rup.perda_estimada.sum())
        decisoes.append(dict(
            id="D4", area="Operações", status="Agir agora", titulo=f"{len(rup)} produtos sem estoque no trimestre",
            pergunta="Quais produtos repor primeiro?",
            indicador=dict(nome="Dias de ruptura no trimestre", valor=f"{len(rup)} produtos acima de {int(P('gatilho_ruptura_dias'))} dias", gatilho=f"Dispara com ≥ {int(P('gatilho_ruptura_dias'))} dias de ruptura em 3 meses",
                           leitura=f"Em média {pt(rup.ruptura_dias.mean(), 0)} dias sem produto em 92 possíveis."),
            sinais=[dict(r="Queda observada de vendas", v=f"{mi(queda, 2)} em 3 meses"), dict(r="Perda estimada (sem substituição)", v=mi(perda_est, 2)),
                    dict(r="Linhas afetadas", v=" e ".join(sorted(rup.linha.unique()))), dict(r="Maior perda", v=f"{rup.iloc[0].nome} ({mil(rup.iloc[0].perda_estimada)})")],
            evidencia=dict(nivel="Moderada", porque=f"A queda observada ({pt(100 * queda / perda_est, 0)}% da perda estimada) é menor porque parte da venda migrou para outros produtos da mesma linha. A perda real fica entre os dois números."),
            alternativas=["Queda de demanda pelo produto (não só falta de estoque)", "Cliente comprou o substituto e ficou satisfeito", "Atraso de fornecedor, que exige outra ação"],
            acao=f"Antecipar o pedido de reposição dos {len(rup)} produtos, começando por {rup.iloc[0].nome}, e rever o ponto de reposição.",
            responsavel="Gerente de Compras e Supply", prazo="7 dias",
            impacto=dict(rotulo="Margem bruta em jogo", valor=round(perda_est * mg_unit, 2), tipo="Estimado",
                         texto=f"Perda estimada de {mi(perda_est, 2)} em receita × margem de {pt(100 * mg_unit)}% = {mi(perda_est * mg_unit, 2)}; piso observado: {mi(queda, 2)} em receita",
                         premissa="Venda diária de jan-jun/2026 × dias de ruptura, sem substituição por outros produtos."),
            acompanhar="Dias de ruptura por produto e cobertura de estoque em dias, toda semana",
            revisar_se="Se a venda não voltar ao nível anterior 30 dias após repor, o problema é demanda e não estoque.",
            tabela=dict(colunas=["Produto", "Linha", "Dias de ruptura", "Queda observada", "Perda estimada"],
                        linhas=[[r.nome, r.linha, int(r.ruptura_dias), round(float(r.queda_observada)), round(float(r.perda_estimada))] for r in rup.itertuples()])))

    # ---------------------------------------------------------------- D3 entrega no prazo
    otd = q("SELECT * FROM vw_otd_regiao")
    po = otd.pivot(index="regiao", columns="janela")
    meta = 100 * P("meta_otd")
    piora = [r for r in po.index if po.loc[r, ("otd_pct", "atual")] < meta and po.loc[r, ("otd_pct", "atual")] - po.loc[r, ("otd_pct", "anterior")] <= -3]
    da = q("SELECT * FROM vw_devolucao_atraso").set_index("grupo")
    if piora:
        rg = piora[0]
        atu, ant = float(po.loc[rg, ("otd_pct", "atual")]), float(po.loc[rg, ("otd_pct", "anterior")])
        rec_rg = float(po.loc[rg, ("receita", "atual")])
        rec_atrasada = rec_rg * (1 - atu / 100)
        extra_dev = rec_atrasada * (float(da.loc["atrasado", "devol_pct_receita"]) - float(da.loc["no_prazo", "devol_pct_receita"])) / 100
        cz = q(f"""SELECT SUM(CASE WHEN ano_mes > strftime('%Y-%m', date((SELECT valor FROM parametros WHERE chave='as_of'),'-3 months')) THEN 1.0*cancelados END)
                          / SUM(CASE WHEN ano_mes > strftime('%Y-%m', date((SELECT valor FROM parametros WHERE chave='as_of'),'-3 months')) THEN pedidos_total END) AS atu,
                          SUM(CASE WHEN ano_mes <= strftime('%Y-%m', date((SELECT valor FROM parametros WHERE chave='as_of'),'-3 months')) AND ano_mes > strftime('%Y-%m', date((SELECT valor FROM parametros WHERE chave='as_of'),'-6 months')) THEN 1.0*cancelados END)
                          / SUM(CASE WHEN ano_mes <= strftime('%Y-%m', date((SELECT valor FROM parametros WHERE chave='as_of'),'-3 months')) AND ano_mes > strftime('%Y-%m', date((SELECT valor FROM parametros WHERE chave='as_of'),'-6 months')) THEN pedidos_total END) AS ant
                   FROM vw_cubo_mensal WHERE regiao='{rg}'""").iloc[0]
        ped_atu = float(po.loc[rg, ("entregues", "atual")]) / (1 - float(cz.atu))
        tk = rec_rg / float(po.loc[rg, ("entregues", "atual")])
        extra_cancel = max(0.0, (float(cz.atu) - float(cz.ant))) * ped_atu * tk
        custo = extra_dev + extra_cancel
        outros = [r for r in po.index if r != rg and po.loc[r, ("otd_pct", "atual")] < meta]
        nota_outros = "; ".join(f"{r} está abaixo da meta ({pt(po.loc[r, ('otd_pct', 'atual')])}%) mas {'melhorou' if po.loc[r, ('otd_pct', 'atual')] > po.loc[r, ('otd_pct', 'anterior')] else 'piorou'} {pt(abs(po.loc[r, ('otd_pct', 'atual')] - po.loc[r, ('otd_pct', 'anterior')]))} p.p.: não é prioridade, mas vale revisar a meta regional" for r in outros)
        mult_dev = float(da.loc["atrasado", "taxa_devolucao_pedidos"]) / float(da.loc["no_prazo", "taxa_devolucao_pedidos"])
        mult_ch = float(da.loc["atrasado", "taxa_chamado"]) / float(da.loc["no_prazo", "taxa_chamado"])
        decisoes.append(dict(
            id="D3", area="Operações", status="Agir agora" if custo * margem_ttm >= 100_000 else "Investigar", titulo=f"Entregas no prazo em queda no {rg}",
            pergunta="Onde está o gargalo de entrega e quem resolve?",
            indicador=dict(nome=f"Entregas no prazo (OTD) · {rg}", valor=f"{pt(atu)}% (era {pt(ant)}%)", gatilho=f"Meta {pt(meta, 0)}%; dispara se abaixo da meta e com queda ≥ 3 p.p.",
                           leitura=f"Queda de {pt(ant - atu)} p.p. em 3 meses; as outras regiões estão estáveis."),
            sinais=[dict(r="Devolução em pedido atrasado", v=f"{pt(float(da.loc['atrasado', 'taxa_devolucao_pedidos']))}% (no prazo: {pt(float(da.loc['no_prazo', 'taxa_devolucao_pedidos']))}%) · {pt(mult_dev, 1)}×"),
                    dict(r="Chamados em pedido atrasado", v=f"{pt(float(da.loc['atrasado', 'taxa_chamado']))}% (no prazo: {pt(float(da.loc['no_prazo', 'taxa_chamado']))}%) · {pt(mult_ch, 1)}×"),
                    dict(r="Cancelamentos na região", v=f"{pt(100 * float(cz.ant), 2)}% → {pt(100 * float(cz.atu), 2)}%"), dict(r="Receita entregue com atraso (3m)", v=mi(rec_atrasada, 2))],
            evidencia=dict(nivel="Moderada", porque=f"Pedido atrasado gera {pt(mult_dev, 1)}× mais devolução e {pt(mult_ch, 1)}× mais chamados (todas as regiões, 6 meses). Os dados não mostram a causa do atraso (transportadora, centro de distribuição ou volume)."),
            alternativas=["Problema da transportadora regional", "Capacidade do centro de distribuição", "Mudança no mix de pedidos (mais itens por pedido)", nota_outros] if nota_outros else ["Problema da transportadora regional", "Capacidade do centro de distribuição", "Mudança no mix de pedidos"],
            acao=f"Abrir revisão do SLA com a transportadora e do fluxo do centro de distribuição para o {rg}, com plano de ação em 30 dias. O custo direto medido é baixo, então a ação é proporcional: diagnosticar a causa antes de gastar com solução.",
            responsavel="Gerente de Logística", prazo="30 dias",
            impacto=dict(rotulo="Margem bruta em jogo", valor=round(custo * margem_ttm, 2), tipo="Estimado",
                         texto=f"Devoluções extras de {mil(extra_dev)} + cancelamentos extras de {mil(extra_cancel)} em 3 meses = {mil(custo)} de receita (× margem {pt(100 * margem_ttm)}%)",
                         premissa="Mede só o custo direto. O efeito do atraso sobre a recompra dos clientes não é medido nesta base e provavelmente é maior."),
            acompanhar=f"OTD semanal do {rg} e chamados por 100 pedidos",
            revisar_se=f"Se o OTD do {rg} não voltar a 88% em 60 dias, escalar para renegociar contrato ou trocar de operador.",
            tabela=dict(colunas=["Região", "OTD anterior %", "OTD atual %", "Entregues (atual)"],
                        linhas=[[r, round(float(po.loc[r, ("otd_pct", "anterior")]), 1), round(float(po.loc[r, ("otd_pct", "atual")]), 1), int(po.loc[r, ("entregues", "atual")])] for r in po.index])))

    # ---------------------------------------------------------------- D5 desconto por vendedor
    vd = q("SELECT * FROM vw_vendedor_desconto ORDER BY z DESC")
    flag = vd[vd.z >= P("gatilho_vendedor_z")]
    if len(flag):
        extra_total, partes = 0.0, []
        for r in flag.itertuples():
            pares = vd[(vd.regiao == r.regiao) & (vd.vendedor_id != r.vendedor_id)]
            d_pares = 100 * (1 - pares.receita.sum() / pares.bruto.sum())
            extra = float(r.bruto) * (float(r.desconto_pct) - d_pares) / 100
            extra_total += max(extra, 0)
            partes.append(f"{r.vendedor_id} ({r.regiao}): {pt(r.desconto_pct)}% contra {pt(d_pares)}% dos pares da região")
        decisoes.append(dict(
            id="D5", area="Comercial", status="Investigar", titulo=f"{len(flag)} vendedores com desconto fora do padrão",
            pergunta="O desconto acima dos pares tem justificativa?",
            indicador=dict(nome="Desconto médio por vendedor (6 meses)", valor=", ".join(f"{r.vendedor_id} {pt(r.desconto_pct)}%" for r in flag.itertuples()), gatilho=f"Dispara com z-score ≥ {pt(P('gatilho_vendedor_z'))} contra os demais vendedores",
                           leitura="Os dois ficam acima dos pares da própria região, o que reduz a chance de ser só efeito de região."),
            sinais=[dict(r="Comparação com pares", v=p) for p in partes] + [dict(r="Média dos demais vendedores", v=f"{pt(vd[~vd.vendedor_id.isin(flag.vendedor_id)].desconto_pct.mean())}%")],
            evidencia=dict(nivel="Moderada", porque="A diferença aparece contra os pares da mesma região. O mix de segmento e de linha de cada carteira ainda pode explicar parte dela e precisa ser conferido antes de qualquer conclusão sobre o vendedor."),
            alternativas=["Carteira com mais clientes de Atacado (desconto maior por política)", "Mais vendas de Eletrônicos, onde o desconto subiu", "Negociação autorizada pela gerência"],
            acao="Conferir o mix de cada carteira e as aprovações de desconto antes de qualquer conversa; se não houver justificativa, rever a alçada.",
            responsavel="Gerente Comercial Regional", prazo="21 dias",
            impacto=dict(rotulo="Margem bruta em jogo", valor=round(extra_total, 2), tipo="Estimado",
                         texto=f"{mi(extra_total, 2)} de desconto acima do que os pares da região dariam, em 6 meses",
                         premissa="Valor a preço de lista do vendedor × (desconto dele − desconto dos pares da região). Supõe o mesmo mix dos pares."),
            acompanhar="Desconto por vendedor contra a mediana da região, todo mês",
            revisar_se="Se o desconto cair para o nível dos pares sem perda de pedidos, a alçada resolve; se os pedidos caírem, o desconto estava comprando volume.",
            tabela=dict(colunas=["Vendedor", "Região", "Desconto %", "Margem %", "Z-score"],
                        linhas=[[r.vendedor_id, r.regiao, round(float(r.desconto_pct), 2), round(float(r.margem_pct), 2), round(float(r.z), 2)] for r in vd.itertuples()])))

    # ---------------------------------------------------------------- D7 sazonalidade
    saz = q("SELECT * FROM vw_sazonalidade").set_index("mes").indice
    por_ano = q("""SELECT substr(ano_mes,1,4) ano, CAST(substr(ano_mes,6,2) AS INT) mes, SUM(receita) rec FROM vw_cubo_mensal WHERE ano_mes < '2026-01' GROUP BY 1,2""")
    pico_ambos = all(float(por_ano[(por_ano.ano == a) & (por_ano.mes == 12)].rec.iloc[0]) > 1.2 * float(por_ano[por_ano.ano == a].rec.mean()) for a in ("2024", "2025"))
    decisoes.append(dict(
        id="D7", area="Planejamento", status="Planejar", titulo="Pico de novembro e dezembro",
        pergunta="A alta de fim de ano é desvio ou rotina?",
        indicador=dict(nome="Índice sazonal (média do ano = 1,00)", valor=f"nov {pt(saz[11], 2)} · dez {pt(saz[12], 2)} · jan {pt(saz[1], 2)}", gatilho="Não é gatilho de correção: é referência de planejamento",
                       leitura="O pico se repetiu em 2024 e 2025." if pico_ambos else "O pico não se repetiu nos dois anos."),
        sinais=[dict(r="Dezembro vs média do ano", v=f"+{pt(100 * (saz[12] - 1), 0)}%"), dict(r="Janeiro vs média do ano", v=f"{pt(100 * (saz[1] - 1), 0)}%"),
                dict(r="Padrão repetido em 2024 e 2025", v="Sim" if pico_ambos else "Não")],
        evidencia=dict(nivel="Forte" if pico_ambos else "Hipótese", porque="Mesmo padrão em dois anos completos. Com só dois anos, ainda não dá para separar sazonalidade de efeito de campanha."),
        alternativas=["Campanha de fim de ano específica (Black Friday)", "Antecipação de compra dos clientes antes de reajuste"],
        acao="Não tratar a alta de nov/dez como desvio. Reforçar estoque e capacidade logística de outubro a dezembro, especialmente nos produtos em ruptura (D4).",
        responsavel="Planejamento de vendas e operações (S&OP)", prazo="Até 15/10",
        impacto=dict(rotulo="Margem bruta em jogo", valor=0, tipo="Estimado", texto="Sem valor calculado: evita falsos alertas e orienta estoque", premissa="Sem premissa."),
        acompanhar="Realizado contra o orçado de nov/dez por região",
        revisar_se="Se nov/2026 vier abaixo do índice 1,15, revisar o plano antes de dezembro.",
        tabela=dict(colunas=["Mês", "Índice"], linhas=[[int(m), float(v)] for m, v in saz.items()])))

    # ---------------------------------------------------------------- D6 concentração
    top10 = float(conc[conc.rk <= 10].pct.sum())
    gat = 100 * P("gatilho_concentracao")
    decisoes.append(dict(
        id="D6", area="Comercial", status="Agir agora" if top10 >= gat else "Monitorar", titulo="Dependência dos maiores clientes",
        pergunta="Perder um grande cliente quebra o resultado?",
        indicador=dict(nome="Receita dos 10 maiores clientes", valor=f"{pt(top10)}% da receita 12m", gatilho=f"Dispara com ≥ {pt(gat, 0)}%", leitura="Abaixo do gatilho: a carteira é pulverizada."),
        sinais=[dict(r="Maior cliente", v=f"{pt(float(conc.iloc[0].pct))}% da receita"), dict(r="Top 10", v=f"{pt(top10)}%"), dict(r="Clientes ativos 12m", v=str(len(conc)))],
        evidencia=dict(nivel="Forte", porque="Medido sobre toda a receita dos últimos 12 meses."),
        alternativas=[],
        acao="Nenhuma ação agora. Manter o indicador no painel e agir se passar do gatilho.",
        responsavel="Diretor Comercial", prazo="Revisão trimestral",
        impacto=dict(rotulo="Margem bruta em jogo", valor=0, tipo="Observado", texto="Sem ação, sem custo", premissa="Sem premissa."),
        acompanhar="Participação do top 10 e do maior cliente, todo trimestre",
        revisar_se=f"Se o top 10 passar de {pt(gat, 0)}% ou um cliente passar de 5%, abrir plano de diversificação.",
        tabela=dict(colunas=["#", "Cliente", "Segmento", "% da receita", "% acumulado"],
                    linhas=[[int(r.rk), r.nome, r.segmento, round(float(r.pct), 2), round(float(r.pct_acum), 2)] for r in conc.head(10).itertuples()])))

    ordem_status = {"Agir agora": 0, "Investigar": 1, "Planejar": 2, "Monitorar": 3}
    decisoes.sort(key=lambda d: (ordem_status[d["status"]], -d["impacto"]["valor"]))
    for i, d in enumerate(decisoes, start=1):
        d["ordem"] = i

    # ---------------------------------------------------------------- demais blocos
    vend = q("SELECT * FROM vw_vendedor_desconto ORDER BY z DESC")
    qual = q("SELECT * FROM vw_qualidade")
    r2 = lambda df: df.round(2)
    out = dict(
        meta=dict(empresa="Vertix Distribuidora (fictícia)", as_of=par["as_of"], simulado=True, periodo=[cubo.ano_mes.min(), cubo.ano_mes.max()],
                  metas=dict(otd=100 * P("meta_otd"), devolucao=100 * P("meta_devolucao"), resolucao_dias=P("meta_resolucao_dias")),
                  parametros={k: v for k, v in par.items()}, gerado=datetime.now().strftime("%Y-%m-%d")),
        regioes=sorted(cubo.regiao.unique()), linhas=sorted(cubo.linha.unique()), segmentos=sorted(cubo.segmento.unique()),
        cubo=[dict(m=r.ano_mes, r=r.regiao, l=r.linha, s=r.segmento, rec=round(r.receita, 2), cus=round(r.custo, 2), bru=round(r.bruto, 2), ped=int(r.pedidos), pt=int(r.pedidos_total),
                   can=int(r.cancelados), ent=int(r.entregues), np=int(r.no_prazo), lt=round(r.leadtime_dias, 1), at=round(r.atraso_dias, 1), dev=round(r.devol_valor, 2),
                   ch=int(r.chamados), chr=int(r.chamados_resolvidos), rd=round(r.resolucao_dias, 1)) for r in cubo.itertuples()],
        plano=[dict(m=r.ano_mes, r=r.regiao, l=r.linha, bud=round(r.receita_orcada, 2), bm=round(r.margem_orcada_pct, 4), fc=round(r.receita_forecast, 2)) for r in plano.itertuples()],
        ativos=[dict(m=r.ano_mes, r=r.regiao, s=r.segmento, a=int(r.ativos)) for r in ativos.itertuples()],
        vendedores=r2(vend).to_dict("records"),
        concentracao=[dict(rk=int(r.rk), nome=r.nome, segmento=r.segmento, tier=r.tier, regiao=r.regiao, receita=round(float(r.receita), 2), pct=round(float(r.pct), 2)) for r in conc.head(15).itertuples()],
        sazonalidade=[dict(mes=int(m), indice=float(v)) for m, v in saz.items()],
        qualidade=qual.to_dict("records"),
        decisoes=decisoes)
    SAIDA.parent.mkdir(parents=True, exist_ok=True)
    SAIDA.write_text(json.dumps(out, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"data.json: {SAIDA.stat().st_size / 1e3:,.0f} KB | cubo {len(out['cubo'])} linhas | decisões: " +
          ", ".join(f"{d['id']}={d['status']}" for d in decisoes))
    con.close()


if __name__ == "__main__":
    main()
