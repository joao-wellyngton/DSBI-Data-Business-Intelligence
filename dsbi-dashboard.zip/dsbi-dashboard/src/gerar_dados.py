#!/usr/bin/env python3
"""
Gera data/dsbi.db (SQLite) com a base SIMULADA da empresa fictícia "Vertix Distribuidora".

Tudo é inventado: clientes, vendedores, produtos, pedidos. Nenhuma empresa ou pessoa real é representada.

A base traz "histórias" plantadas (e documentadas) para que os indicadores tenham o que revelar:
  H1  Margem de Eletrônicos cai a partir de out/2025 (desconto sobe mês a mês; volume sobe pouco)
  H2  Entregas no prazo do Nordeste pioram a partir de mar/2026
  H3  Carteira do vendedor V04 (Sudeste, desligado em mai/2026): 28 clientes param de comprar
  H4  6 produtos (Eletrônicos e Ferramentas) em ruptura de estoque em jul-set/2026
  H5  Vendedores V03 e V09 dão ~3,5 p.p. a mais de desconto que os pares, o período todo
  H6  Sazonalidade forte em nov/dez (esperada, não é problema)
O orçamento (plano) é feito do jeito comum: ano anterior + crescimento planejado, sem saber das histórias.

Uso:  python src/gerar_dados.py
"""
import sqlite3
from datetime import date, timedelta
from pathlib import Path

import numpy as np

RAIZ = Path(__file__).resolve().parent.parent
DB = RAIZ / "data" / "dsbi.db"
AS_OF = date(2026, 9, 30)
INICIO = date(2024, 1, 1)
rng = np.random.default_rng(7)

NM = 33  # jan/2024 .. set/2026
def ym(t): return f"{2024 + t // 12}-{t % 12 + 1:02d}"
def tidx(y, m): return (y - 2024) * 12 + m - 1

REG = {
    "Sudeste":      dict(peso=.38, prazo=3, late=.06, g=.008, ufs=["SP", "RJ", "MG", "ES"]),
    "Sul":          dict(peso=.20, prazo=4, late=.07, g=.008, ufs=["PR", "SC", "RS"]),
    "Nordeste":     dict(peso=.22, prazo=6, late=.09, g=.010, ufs=["BA", "PE", "CE", "RN", "PB"]),
    "Centro-Oeste": dict(peso=.12, prazo=5, late=.10, g=.009, ufs=["GO", "MT", "MS", "DF"]),
    "Norte":        dict(peso=.08, prazo=9, late=.15, g=.016, ufs=["PA", "AM", "RO"]),
}
VEND = {  # vendedor -> região
    "V01": "Sudeste", "V02": "Sudeste", "V03": "Sudeste", "V04": "Sudeste",
    "V05": "Sul", "V06": "Sul", "V07": "Nordeste", "V08": "Nordeste", "V09": "Nordeste",
    "V10": "Centro-Oeste", "V11": "Centro-Oeste", "V12": "Norte",
}
NOMES_V = ["Ana Moura", "Bruno Leal", "Carla Dias", "Diego Horta", "Elisa Pires", "Fábio Ramos", "Gisele Tavares",
           "Hugo Klein", "Iara Seixas", "João Nogueira", "Karen Uchoa", "Lucas Zanetti"]
LINHAS = {  # margem base, faixa de preço, quantidade típica por item
    "Eletrônicos":          dict(m=.22, preco=(400, 3000), q=2),
    "Casa & Cozinha":       dict(m=.34, preco=(60, 500), q=6),
    "Escritório":           dict(m=.38, preco=(20, 250), q=12),
    "Ferramentas":          dict(m=.30, preco=(80, 900), q=4),
    "Higiene & Limpeza":    dict(m=.26, preco=(15, 120), q=20),
}
LN = list(LINHAS)
SEGS = ["Varejo", "Atacado", "Indústria", "Serviços"]
SEG_P = [.50, .20, .15, .15]
SEG_LINHA = {
    "Varejo":    [.25, .30, .12, .10, .23], "Atacado": [.20, .22, .15, .13, .30],
    "Indústria": [.10, .10, .20, .50, .10], "Serviços": [.15, .10, .50, .10, .15],
}
SEG_QTD = {"Varejo": 1.0, "Atacado": 2.5, "Indústria": 1.6, "Serviços": .8}
TIER_DESC = {"Ouro": .07, "Prata": .045, "Bronze": .02}
SEASON = [.82, .85, .95, .97, 1.0, .98, 1.0, 1.02, 1.03, 1.08, 1.25, 1.35]
CANAIS, CANAL_P = ["Direto", "Distribuidor", "E-commerce"], [.60, .25, .15]
T_CREEP0 = tidx(2025, 10)   # H1
T_NE0 = tidx(2026, 3)       # H2
T_RUP = [tidx(2026, 7), tidx(2026, 8), tidx(2026, 9)]  # H4

SOBRENOMES = ["Almeida", "Barros", "Cardoso", "Dias", "Esteves", "Fontes", "Guedes", "Horta", "Ibrahim", "Jardim",
              "Klein", "Leal", "Moura", "Nogueira", "Ornelas", "Pires", "Queiroz", "Ramos", "Seixas", "Tavares",
              "Uchoa", "Valadares", "Xavier", "Zanetti", "Amaral", "Bastos", "Camargo", "Duarte"]
PREF = {"Varejo": ["Mercado", "Loja", "Magazine", "Empório"], "Atacado": ["Atacadão", "Distribuidora"],
        "Indústria": ["Indústria", "Metalúrgica", "Fábrica"], "Serviços": ["Clínica", "Escola", "Hotel", "Oficina"]}
SUF = ["Central", "Horizonte", "Aurora", "União", "Planalto", "Progresso", "Estrela", "Vale Verde", "Nova Era", "Imperial"]


def dias_mes(t):
    y, m = 2024 + t // 12, t % 12 + 1
    d = date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1)
    return d.day


def main():
    DB.parent.mkdir(exist_ok=True)
    if DB.exists():
        DB.unlink()
    con = sqlite3.connect(DB)
    con.executescript((RAIZ / "sql" / "01_schema.sql").read_text(encoding="utf-8"))

    # ------------------------------------------------------------ produtos
    prods = []
    pid = 1
    for ln, cfg in LINHAS.items():
        for k in range(8):
            preco = float(np.exp(rng.uniform(np.log(cfg["preco"][0]), np.log(cfg["preco"][1]))))
            custo = preco * (1 - cfg["m"] + rng.uniform(-.03, .03))
            prods.append(dict(id=pid, nome=f"{ln.split()[0]} {k + 1:02d}", linha=ln, preco=round(preco, 2), custo=round(custo, 2),
                              pop=1 / (k + 1) ** .8))
            pid += 1
    por_linha = {ln: [p for p in prods if p["linha"] == ln] for ln in LN}

    # ruptura de estoque (H4) e ruído de base
    rup = rng.choice([0, 1, 2, 3, 4], size=(len(prods), NM), p=[.94, .02, .02, .01, .01])
    plant = [por_linha["Eletrônicos"][0], por_linha["Eletrônicos"][2], por_linha["Eletrônicos"][4],
             por_linha["Ferramentas"][0], por_linha["Ferramentas"][1], por_linha["Ferramentas"][3]]
    for j, p in enumerate(plant):
        for t, d in zip(T_RUP, [(8, 11, 14), (9, 12, 13), (7, 10, 12)][j % 3]):
            rup[p["id"] - 1, t] = d
    plant_ids = {p["id"] for p in plant}
    pesos_prod = {}
    for ln in LN:
        for t in range(NM):
            w = np.array([p["pop"] * max(0.05, 1 - .9 * rup[p["id"] - 1, t] / 30) for p in por_linha[ln]])
            pesos_prod[(ln, t)] = w / w.sum()

    # ------------------------------------------------------------ clientes
    N = 620
    s = rng.lognormal(0, .9, N)
    ordem = np.argsort(-s)
    tier = np.empty(N, dtype=object)
    tier[ordem[:int(N * .08)]] = "Ouro"; tier[ordem[int(N * .08):int(N * .30)]] = "Prata"; tier[ordem[int(N * .30):]] = "Bronze"
    seg = rng.choice(SEGS, N, p=SEG_P)
    regs = list(REG)
    reg = rng.choice(regs, N, p=[REG[r]["peso"] for r in regs])
    vend = np.array([rng.choice([v for v, r in VEND.items() if r == rg]) for rg in reg])
    antigo = rng.random(N) < .7
    cad = []
    for i in range(N):
        if antigo[i]:
            cad.append(date(2019, 1, 1) + timedelta(days=int(rng.integers(0, 365 * 5))))
        else:
            cad.append(INICIO + timedelta(days=int(rng.integers(0, 900))))
    stop = [None] * N
    for i in range(N):  # churn natural, ~0,6%/mês
        k = int(rng.geometric(.006))
        t0 = max(0, tidx(cad[i].year, cad[i].month))
        if t0 + k < NM:
            tt = t0 + k
            stop[i] = date(2024 + tt // 12, tt % 12 + 1, dias_mes(tt))
    # H3: 28 maiores clientes de V04 param de comprar após a saída do vendedor
    v04 = [i for i in range(N) if vend[i] == "V04"]
    v04.sort(key=lambda i: -s[i])
    h3 = v04[:28]
    for i in h3:
        stop[i] = date(2026, 5, 20) + timedelta(days=int(rng.integers(0, 50)))
        cad[i] = min(cad[i], date(2023, 6, 1))
    nomes = []
    usados = set()
    for i in range(N):
        while True:
            n = f"{rng.choice(PREF[seg[i]])} {rng.choice(SOBRENOMES)} {rng.choice(SUF)}"
            if n not in usados:
                usados.add(n); nomes.append(n); break
    ufs = [rng.choice(REG[r]["ufs"]) for r in reg]

    con.executemany("INSERT INTO regioes VALUES (?,?)", [(r, c["prazo"]) for r, c in REG.items()])
    con.executemany("INSERT INTO vendedores VALUES (?,?,?,?,?)",
                    [(v, NOMES_V[k], r, 0 if v == "V04" else 1, "2026-05-15" if v == "V04" else None)
                     for k, (v, r) in enumerate(VEND.items())])
    con.executemany("INSERT INTO clientes VALUES (?,?,?,?,?,?,?,?)",
                    [(i + 1, nomes[i], str(seg[i]), str(tier[i]), str(reg[i]), str(ufs[i]), str(vend[i]), cad[i].isoformat()) for i in range(N)])
    con.executemany("INSERT INTO produtos VALUES (?,?,?,?,?)", [(p["id"], p["nome"], p["linha"], p["preco"], p["custo"]) for p in prods])

    # ------------------------------------------------------------ pedidos
    # frequência esperada por cliente-mês, calibrada para ~31 mil pedidos
    lam = np.zeros((N, NM))
    for i in range(N):
        for t in range(NM):
            ini = max(cad[i], INICIO)
            fim = stop[i] or AS_OF
            d0, d1 = date(2024 + t // 12, t % 12 + 1, 1), date(2024 + t // 12, t % 12 + 1, dias_mes(t))
            ativo = max(0, (min(d1, fim, AS_OF) - max(d0, ini)).days + 1) / dias_mes(t)
            lam[i, t] = ativo * s[i] ** .65 * SEASON[t % 12] * (1 + REG[reg[i]]["g"]) ** t
    lam *= 31000 / lam.sum()

    pedidos, itens = [], []
    peso_dia = np.array([1, 1, 1, 1, 1, .25, .05])
    for i in range(N):
        sg, tr, rg, vd = str(seg[i]), str(tier[i]), str(reg[i]), str(vend[i])
        esc = float(np.clip(s[i] ** .3, .7, 1.6))
        for t in range(NM):
            n = int(rng.poisson(lam[i, t]))
            if n == 0:
                continue
            y, m = 2024 + t // 12, t % 12 + 1
            dm = dias_mes(t)
            ini, fim = max(cad[i], INICIO), min(stop[i] or AS_OF, AS_OF)
            dias = [date(y, m, d) for d in range(1, dm + 1) if ini <= date(y, m, d) <= fim]
            if not dias:
                continue
            pw = np.array([peso_dia[d.weekday()] for d in dias]); pw = pw / pw.sum()
            for _ in range(n):
                dp = dias[int(rng.choice(len(dias), p=pw))]
                k_el = max(0, t - T_CREEP0 + 1)
                lw = np.array(SEG_LINHA[sg], dtype=float)
                lw[0] *= 1 + .0045 * min(k_el, 12)
                lw /= lw.sum()
                ln = LN[int(rng.choice(5, p=lw))]
                ni = 1 + int(rng.poisson(1.8 * esc))
                ni = min(ni, 12)
                pp = pesos_prod[(ln, t)]
                escolhidos = rng.choice(len(por_linha[ln]), size=ni, p=pp)
                bruto = liq = custo = 0.0
                it = []
                for ix in escolhidos:
                    p = por_linha[ln][int(ix)]
                    q = max(1, int(round(rng.lognormal(np.log(LINHAS[ln]["q"] * SEG_QTD[sg]), .6))))
                    d = TIER_DESC[tr] + (.03 if sg == "Atacado" else 0) + (.035 if vd in ("V03", "V09") else 0)
                    if ln == "Eletrônicos" and t >= T_CREEP0:
                        d += .0075 * (t - T_CREEP0 + 1) * (1.25 if vd in ("V03", "V09") else 1.0)
                    d = float(np.clip(d + rng.normal(0, .012), 0, .35))
                    pu = round(p["preco"] * (1 - d), 2)
                    it.append((p["id"], q, pu, round(d, 4), p["custo"]))
                    bruto += p["preco"] * q; liq += pu * q; custo += p["custo"] * q
                # logística
                late_p = REG[rg]["late"]
                extra_late = 0
                if rg == "Nordeste" and t >= T_NE0:
                    late_p += .21 * min(1, (t - T_NE0 + 1) / 7)
                    extra_late = 2
                late = rng.random() < late_p
                prazo = REG[rg]["prazo"]
                prometida = dp + timedelta(days=prazo)
                if late:
                    entrega = prometida + timedelta(days=1 + int(rng.poisson(1.5)) + (int(rng.poisson(extra_late)) if extra_late else 0))
                else:
                    entrega = prometida - timedelta(days=int(rng.integers(0, 2)))
                cancel = rng.random() < (.045 if late else .012)
                if cancel:
                    status, ent = "cancelado", None
                elif entrega > AS_OF:
                    status, ent = "em_transito", None
                else:
                    status, ent = "entregue", entrega
                canal = str(rng.choice(CANAIS, p=CANAL_P))
                pedidos.append(dict(cli=i + 1, vend=vd, reg=rg, ln=ln, canal=canal, dp=dp, prom=prometida, ent=ent, status=status,
                                    bruto=round(bruto, 2), liq=round(liq, 2), custo=round(custo, 2), late=late, it=it))
    pedidos.sort(key=lambda p: (p["dp"], p["cli"]))

    ped_rows, item_rows, dev_rows, cham_rows = [], [], [], []
    cid = 1
    for k, p in enumerate(pedidos, start=1):
        ped_rows.append((k, p["cli"], p["vend"], p["reg"], p["ln"], p["canal"], p["dp"].isoformat(), p["prom"].isoformat(),
                         p["ent"].isoformat() if p["ent"] else None, p["status"], p["bruto"], p["liq"], p["custo"]))
        for (pr, q, pu, d, cu) in p["it"]:
            item_rows.append((k, pr, q, pu, d, cu))
        if p["status"] == "entregue":
            if rng.random() < (.05 if p["late"] else .018):
                dd = p["ent"] + timedelta(days=int(rng.integers(2, 16)))
                if dd <= AS_OF:
                    dev_rows.append((k, dd.isoformat(), round(p["liq"] * float(rng.uniform(.25, 1.0)), 2),
                                     str(rng.choice(["Defeito", "Atraso", "Erro de pedido", "Arrependimento"], p=[.4, .25, .2, .15]))))
            if rng.random() < (.15 if p["late"] else .05):
                cat = str(rng.choice(["Atraso", "Produto", "Faturamento", "Outros"],
                                     p=[.6, .15, .15, .1] if p["late"] else [.05, .4, .3, .25]))
                ab = p["ent"] + timedelta(days=int(rng.integers(0, 6)))
                if ab <= AS_OF:
                    res = max(0, int(round(rng.lognormal(np.log(2), .6))))
                    fe = ab + timedelta(days=res)
                    cham_rows.append((cid, k, p["cli"], cat, ab.isoformat(), fe.isoformat() if fe <= AS_OF else None))
                    cid += 1
    con.executemany("INSERT INTO pedidos VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", ped_rows)
    con.executemany("INSERT INTO pedido_itens VALUES (?,?,?,?,?,?)", item_rows)
    con.executemany("INSERT INTO devolucoes VALUES (?,?,?,?)", dev_rows)
    con.executemany("INSERT INTO chamados VALUES (?,?,?,?,?,?)", cham_rows)

    # ------------------------------------------------------------ estoque (a partir das vendas)
    un = {}
    for r in con.execute("""SELECT i.produto_id, substr(p.data_pedido,1,7), SUM(i.qtd) FROM pedido_itens i
                            JOIN pedidos p USING(pedido_id) WHERE p.status<>'cancelado' GROUP BY 1,2"""):
        un[(r[0], r[1])] = r[2]
    est = []
    for p in prods:
        for t in range(NM):
            u = un.get((p["id"], ym(t)), 0)
            r = int(rup[p["id"] - 1, t])
            cobertura = rng.uniform(15, 40)
            qf = int(u / dias_mes(t) * cobertura) if r < 5 else int(rng.integers(0, 4))
            est.append((p["id"], ym(t), qf, r))
    con.executemany("INSERT INTO estoque_mensal VALUES (?,?,?,?)", est)

    # ------------------------------------------------------------ plano (orçamento e forecast)
    cel = {}
    for r in con.execute("""SELECT substr(data_pedido,1,7), regiao, linha, SUM(valor_liquido), SUM(custo_total)
                            FROM pedidos WHERE status<>'cancelado' GROUP BY 1,2,3"""):
        cel[(r[0], r[1], r[2])] = (r[3], r[4])
    plano = []
    for t in range(NM):
        for rg in REG:
            for ln in LN:
                a = cel.get((ym(t), rg, ln))
                if not a:
                    continue
                rec, cus = a
                marg = 1 - cus / rec
                if t < 12:   # 2024: sem ano anterior -> orçamento ao redor do realizado
                    bud = rec * (1 + rng.normal(.015, .05)); bm = marg + rng.normal(0, .008)
                else:        # ano anterior + crescimento planejado (12% em 2025, 10% em 2026)
                    prev = cel.get((ym(t - 12), rg, ln))
                    g = 1.12 if t < 24 else 1.10
                    if not prev:
                        bud, bm = rec, marg
                    else:
                        bud = prev[0] * g; bm = 1 - prev[1] / prev[0] + .002
                fc = rec * (1 + rng.normal(.003, .025))
                plano.append((ym(t), rg, ln, round(bud, 2), round(bm, 4), round(fc, 2)))
    con.executemany("INSERT INTO plano_mensal VALUES (?,?,?,?,?,?)", plano)

    con.executemany("INSERT INTO parametros VALUES (?,?,?)", [
        ("as_of", AS_OF.isoformat(), "Data de corte dos dados"),
        ("meta_otd", "0.92", "Meta de entregas no prazo"),
        ("meta_devolucao", "0.025", "Teto de taxa de devolução (sobre receita)"),
        ("meta_resolucao_dias", "2.5", "Meta de tempo médio de resolução de chamados"),
        ("gatilho_risco_pct", "3", "Receita em risco (% da receita 12m) que dispara ação comercial"),
        ("risco_dias_min", "90", "Dias sem compra mínimos para marcar cliente em risco"),
        ("risco_mult_intervalo", "3", "Dias sem compra > N x intervalo médio entre compras"),
        ("risco_dias_max", "365", "Acima disso o cliente é considerado perdido (fora da lista de risco)"),
        ("risco_min_pedidos", "4", "Mínimo de pedidos em 24 meses para entrar na regra de risco"),
        ("gatilho_margem_pp", "2", "Queda de margem (p.p.) que dispara revisão de política de desconto"),
        ("gatilho_vendedor_z", "1.5", "Z-score de desconto do vendedor vs pares"),
        ("gatilho_ruptura_dias", "5", "Dias de ruptura no trimestre que disparam reposição"),
        ("gatilho_concentracao", "0.25", "Participação dos 10 maiores clientes na receita 12m"),
        ("premissa_recuperacao", "0.30", "Premissa: % da receita em risco recuperável com ação comercial"),
    ])
    con.commit()
    n_ped = con.execute("SELECT COUNT(*) FROM pedidos").fetchone()[0]
    n_it = con.execute("SELECT COUNT(*) FROM pedido_itens").fetchone()[0]
    rec = con.execute("SELECT SUM(valor_liquido) FROM pedidos WHERE status<>'cancelado'").fetchone()[0]
    print(f"pedidos {n_ped:,} | itens {n_it:,} | receita R$ {rec / 1e6:,.1f} mi | clientes {N} | H3 planta {len(h3)} clientes | rupturas plantadas {sorted(plant_ids)}")
    con.close()


if __name__ == "__main__":
    main()
