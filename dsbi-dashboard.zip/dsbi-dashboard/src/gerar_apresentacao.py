"""Gera docs/Apresentacao_DSBI.pdf: capturas do painel + explicação (16:9). Precisa de playwright."""
from pathlib import Path
from playwright.sync_api import sync_playwright
raiz = Path(__file__).resolve().parent.parent
pasta = raiz / "docs" / "apresentacao"; pasta.mkdir(exist_ok=True)
URL = (raiz / "dashboard" / "index.html").as_uri()

def faixa(pg, filhos, a, b):
    """clip (coords da página) do filho a até o filho b (inclusive)"""
    ra, rb = filhos[a], filhos[b]
    return dict(x=210, y=ra["y"], width=1230, height=rb["y"] + rb["height"] - ra["y"] + 8)

with sync_playwright() as pw:
    br = pw.chromium.launch()
    pg = br.new_page(viewport={"width": 1440, "height": 900}, device_scale_factor=2)
    pg.goto(URL); pg.wait_for_timeout(800)
    plano = {  # aba -> [(arquivo, filho_ini, filho_fim)]
        0: [("exec", 0, 4)],
        1: [("com_a", 0, 2), ("com_b", 3, 4)],
        2: [("ops_a", 0, 2), ("ops_b", 3, 4)],
        3: [("dec_a", 0, 2)],
    }
    for aba, cortes in plano.items():
        pg.locator(".nav").nth(aba).click(); pg.wait_for_timeout(900)
        filhos = pg.evaluate("""() => [...document.querySelector('main.main').children].map(e => {
            const r = e.getBoundingClientRect(); return {y: r.y + scrollY, height: r.height} })""")
        if aba == 3:  # topo + 2 primeiros cartões
            filhos = filhos[:1] + filhos[1:]
        for nome, a, b in cortes:
            b = min(b, len(filhos) - 1)
            pg.screenshot(path=str(pasta / f"{nome}.png"), clip=faixa(pg, filhos, a, b), full_page=True)
    br.close()

slides = [
 ("exec", "Visão executiva", "Em 10 segundos: estamos bem?",
  ["Receita 2026 (até set): <b>R$ 62,0 mi</b>, 2,1% abaixo do orçado e 7,7% acima de 2025.",
   "Margem <b>21,9%</b> e entregas no prazo <b>90,5%</b> (meta 92%).",
   "Cada cartão mostra os 4 trimestres e a distância para orçado, forecast ou meta.",
   "A ponte mostra qual região puxou o resultado para cima ou para baixo."]),
 ("com_a", "Comercial · onde ganhamos e perdemos", "O problema aparece quando se cruza desconto com margem",
  ["Eletrônicos vende R$ 19,9 mi, mas com margem de só <b>10,5%</b> e desconto de 12,4%.",
   "No gráfico de dispersão, os pontos de Eletrônicos ficam isolados lá embaixo.",
   "Clientes ativos sobem com o tempo, mas há quedas bruscas que merecem explicação."]),
 ("com_b", "Comercial · pessoas e carteira", "Quem vende, quem compra e quem sumiu",
  ["Vendedores V03 e V09 dão desconto bem acima do time (z-score 2,6 e 1,7).",
   "Os 10 maiores clientes somam <b>11,2%</b> da receita: sem risco de dependência.",
   "<b>53 clientes</b> pararam de comprar; a maioria era da carteira de V04, que saiu em maio."]),
 ("ops_a", "Operações · entrega", "O Nordeste piorou e o painel mostra onde",
  ["Entrega no prazo oscila perto da meta de 92%.",
   "O mapa de calor cruza região e mês: o Nordeste fica vermelho nos últimos meses.",
   "Nordeste: <b>75,2%</b> no prazo, contra 86,1% antes."]),
 ("ops_b", "Operações · custo da falha", "Devolução, atendimento, estoque e sazonalidade",
  ["Pedido atrasado gera 3,9× mais devolução.",
   "<b>6 produtos</b> ficaram 5 dias ou mais sem estoque no trimestre.",
   "Novembro (1,24) e dezembro (1,38) vendem mais que a média: dá para se preparar."]),
 ("dec_a", "Decisões · do indicador à ação", "O diferencial: cada alerta vira um cartão de decisão",
  ["Fluxo: <b>indicador → gatilho → decisão → dono e prazo → acompanhamento</b>.",
   "Mostra o que os dados provam e <b>outras explicações possíveis</b>.",
   "Impacto marcado como <b>Observado</b> ou <b>Estimado</b>, com a premissa escrita.",
   "Há casos de Monitorar e Planejar: nem todo alerta pede ação."]),
]

css = """
@page{size:1280px 720px;margin:0}
*{box-sizing:border-box}body{margin:0;font-family:Inter,'Helvetica Neue',Arial,sans-serif;color:#e8ecf6}
.s{width:1280px;height:720px;background:#1b2234;page-break-after:always;position:relative;overflow:hidden;padding:36px 44px}
.s:last-child{page-break-after:auto}
.tag{font-size:13px;letter-spacing:.14em;text-transform:uppercase;color:#7fb0f3}
h1{font-size:50px;line-height:1.1;margin:14px 0 14px}h2{font-size:30px;margin:6px 0 20px;line-height:1.2}
.row{display:grid;grid-template-columns:790px 1fr;gap:30px;align-items:start}
.row img{width:790px;border:1px solid #3a4565;border-radius:10px;max-height:590px;object-fit:contain;object-position:top;background:#232c42}
ul{margin:0;padding-left:20px;font-size:19px;line-height:1.5}li{margin-bottom:14px}
.ft{position:absolute;left:44px;bottom:16px;font-size:11px;color:#9aa6c4}.ft.r{left:auto;right:44px}
.cover{background:#141a2b;display:flex;flex-direction:column;justify-content:space-between;padding:56px 64px}
.cover p{font-size:22px;max-width:820px;color:#c5cee4;margin:0}
.kp{display:flex;gap:16px}.kp div{background:#232c42;border:1px solid #3a4565;border-radius:12px;padding:16px 22px}.kp b{display:block;font-size:30px}.kp span{font-size:13px;color:#9aa6c4}
.fl{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:10px 0 26px}
.fl div{background:#232c42;border:1px solid #3a4565;border-radius:12px;padding:16px;font-size:16px;line-height:1.4}.fl b{display:block;color:#7fb0f3;font-size:12px;letter-spacing:.1em;text-transform:uppercase;margin-bottom:6px}
.two{display:grid;grid-template-columns:1fr 1fr;gap:28px}.two ul{font-size:18px}
.warn{background:#3d3420;border:1px solid #8a7330;color:#ffe9a8;border-radius:10px;padding:12px 16px;font-size:16px;margin-top:14px}
img.full{width:1190px;border-radius:10px;border:1px solid #3a4565;background:#fff}
"""
f = lambda n: f"<div class='ft'>DSBI · Studio Hart · dados simulados</div><div class='ft r'>{n}</div>"
h = [f"<div class='s cover'><div><div class='tag'>Apresentação · Business Intelligence</div><h1>DSBI — Data &amp; Business Intelligence</h1><p>Como transformar dados dispersos em indicadores que ajudem gestores a tomar decisões.</p></div>"
     "<div class='kp'><div><b>31.007</b><span>pedidos</span></div><div><b>R$ 217,3 mi</b><span>receita simulada</span></div><div><b>7</b><span>cartões de decisão</span></div><div><b>0</b><span>erros de qualidade</span></div></div>"
     "<div><b>Niel Hart · Studio Hart</b><br><span style='color:#9aa6c4'>SQL · SQLite · React · Recharts · D3 · dados simulados da empresa fictícia Vertix Distribuidora</span></div></div>"]
h.append(f"<div class='s'><div class='tag'>O problema</div><h2>Muito dado, pouca decisão</h2><div class='two'><div><ul><li>Pedidos, estoque, devoluções e chamados vivem em tabelas separadas.</li><li>O gestor vê números, mas não sabe <b>o que fazer</b> nem <b>quem</b> deve agir.</li><li>Gráfico bonito sem decisão não muda nada.</li></ul></div><div><ul><li><b>Resposta:</b> SQL calcula os indicadores, o painel mostra a tendência e cada alerta vira uma decisão com dono e prazo.</li><li>Tudo é testado: totais do painel batem com o SQL.</li></ul></div></div><img class='full' style='display:block;margin:0 auto;height:330px;width:auto' src='../diagrama_pipeline.png'>{f(2)}</div>")
for i, (img, tag, tit, pts) in enumerate(slides):
    h.append(f"<div class='s'><div class='tag'>{tag}</div><h2>{tit}</h2><div class='row'><img src='{img}.png'><ul>{''.join(f'<li>{p}</li>' for p in pts)}</ul></div>{f(i+3)}</div>")
h.append(f"""<div class='s'><div class='tag'>Como ler um cartão</div><h2>Exemplo: clientes que pararam de comprar</h2>
<div class='fl'><div><b>1 · Indicador</b>R$ 11,7 mi de receita em risco (13,4%)</div><div><b>2 · Gatilho</b>Dispara com 3% ou mais da receita em 12 meses</div><div><b>3 · Decisão</b>Reatribuir a carteira de V04 e contatar os 30 clientes em 15 dias</div><div><b>4 · Dono e prazo</b>Diretor Comercial e Gerente Regional · 15 dias</div><div><b>5 · Acompanhar</b>Clientes reativados e receita recuperada</div></div>
<div class='two'><ul><li><b>Evidência forte:</b> V04 tem 11% da carteira e 70% da receita em risco.</li><li><b>Mas atenção:</b> a causa (saída do vendedor) ainda precisa ser confirmada com os clientes.</li></ul><ul><li><b>Impacto estimado:</b> R$ 2,61 mi de margem por ano, assumindo recuperar 30%.</li><li><b>Revisar se:</b> menos de 10% reativarem em 30 dias.</li></ul></div>{f(9)}</div>""")
h.append(f"""<div class='s'><div class='tag'>Resultado e limites</div><h2>O que o projeto entrega</h2><div class='two'><div><ul><li>Painel em <b>1 arquivo</b> que abre offline.</li><li><b>7 decisões:</b> 3 agir agora, 2 investigar, 1 planejar, 1 monitorar.</li><li>Metas e gatilhos ficam na tabela <b>parametros</b>: mudar o limite muda o alerta.</li><li>10 controles de qualidade, todos em zero; testes automáticos passam.</li></ul></div><div><ul><li><b>Limite:</b> dados simulados. Mostra o método, não um resultado real.</li><li><b>Limite:</b> impactos “Estimado” dependem de premissas.</li><li><b>Próximo passo:</b> trocar pela base real e medir se as ações mudaram o indicador.</li></ul></div></div><div class='warn'>Código, SQL e relatório completo estão no repositório do projeto.</div>{f(10)}</div>""")
html = pasta / "_apresentacao.html"
html.write_text(f"<!doctype html><html lang='pt-BR'><head><meta charset='utf-8'><style>{css}</style></head><body>{''.join(h)}</body></html>", encoding="utf-8")
with sync_playwright() as pw:
    br = pw.chromium.launch(); pg = br.new_page(); pg.goto(html.as_uri()); pg.wait_for_timeout(800)
    pg.pdf(path=str(raiz / "docs" / "Apresentacao_DSBI.pdf"), width="1280px", height="720px", print_background=True, prefer_css_page_size=True)
    br.close()
html.unlink(); print("PDF gerado")
