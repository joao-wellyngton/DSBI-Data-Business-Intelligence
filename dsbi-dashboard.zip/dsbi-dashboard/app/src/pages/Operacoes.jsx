import { useMemo } from 'react'
import { LineChart, Line, ComposedChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine, BarChart } from 'recharts'
import { Card, Tip, Chart, Legend2, axis, C } from '../ui/common'
import Heatmap from '../ui/Heatmap'
import { filtraCubo, soma, kpis, agrupa, META, D } from '../calc'
import { pct, dec, mesLabel } from '../fmt'

export default function Operacoes({ f }) {
  const x = useMemo(() => {
    const todos = filtraCubo({ ...f, ano: null })
    const mensal = [...agrupa(todos, (r) => r.m).entries()].sort().map(([m, rs]) => ({ m, ...kpis(soma(rs)) }))
    const meses = mensal.map((s) => s.m)
    const celula = new Map()
    for (const [k, rs] of agrupa(filtraCubo({ ano: null, linha: f.linha }), (r) => r.r + '|' + r.m)) {
      const t = soma(rs); celula.set(k, t.ent ? (100 * t.np) / t.ent : null)
    }
    return { mensal, meses, celula }
  }, [f])
  const d3 = D.decisoes.find((d) => d.id === 'D3')
  const d4 = D.decisoes.find((d) => d.id === 'D4')
  const saz = D.sazonalidade.map((s) => ({ ...s, n: ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'][s.mes - 1] }))
  const meta = META.metas.otd

  return (
    <>
      <div className="grid g2">
        <Card title="Entregas no prazo (OTD)" sub="% de pedidos entregues na data prometida ou antes">
          <Legend2 items={[[C.aqua, 'OTD'], [C.mut, `Meta ${meta}%`]]} />
          <Chart h={250}>
            <LineChart data={x.mensal} margin={{ left: 0, right: 10, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="m" tickFormatter={mesLabel} {...axis} minTickGap={24} />
              <YAxis {...axis} width={40} domain={[80, 100]} tickFormatter={(v) => `${v}%`} />
              <ReferenceLine y={meta} stroke={C.mut} strokeDasharray="5 4" />
              <Tooltip content={<Tip fmt={(v) => pct(v)} labelFmt={mesLabel} />} />
              <Line isAnimationActive={false} dataKey="otd" name="OTD" stroke={C.aqua} strokeWidth={2.4} dot={false} />
            </LineChart>
          </Chart>
        </Card>
        <Card title="Prazo de entrega e atraso" sub="Dias do pedido à entrega (média) e atraso médio dos pedidos atrasados">
          <Legend2 items={[[C.blue, 'Lead time'], [C.orange, 'Atraso médio']]} />
          <Chart h={250}>
            <LineChart data={x.mensal} margin={{ left: 0, right: 10, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="m" tickFormatter={mesLabel} {...axis} minTickGap={24} />
              <YAxis {...axis} width={40} />
              <Tooltip content={<Tip fmt={(v) => `${dec(v)} dias`} labelFmt={mesLabel} />} />
              <Line isAnimationActive={false} dataKey="leadtime" name="Lead time" stroke={C.blue} strokeWidth={2.4} dot={false} />
              <Line isAnimationActive={false} dataKey="atraso" name="Atraso médio" stroke={C.orange} strokeWidth={2.2} dot={false} />
            </LineChart>
          </Chart>
        </Card>
      </div>

      <Card className="mt" title="OTD por região e mês" sub={`Azul-acinzentado = na meta (${meta}%), vermelho = abaixo, verde = acima${f.regiao ? ` · ${f.regiao} em destaque` : ''}`}>
        <Heatmap meses={x.meses} regioes={D.regioes} meta={meta} destaque={f.regiao} valor={(r, m) => x.celula.get(r + '|' + m) ?? null} />
        {d3 && <div className="note">{d3.indicador.leitura}</div>}
      </Card>

      <div className="grid g2 mt">
        <Card title="Devolução e cancelamento" sub={`% sobre receita (devolução) e sobre pedidos (cancelamento) · meta de devolução ${META.metas.devolucao}%`}>
          <Legend2 items={[[C.red, 'Devolução %'], [C.violet, 'Cancelamento %']]} />
          <Chart h={240}>
            <LineChart data={x.mensal} margin={{ left: 0, right: 10, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="m" tickFormatter={mesLabel} {...axis} minTickGap={24} />
              <YAxis {...axis} width={40} tickFormatter={(v) => `${dec(v, 0)}%`} />
              <ReferenceLine y={META.metas.devolucao} stroke={C.mut} strokeDasharray="5 4" />
              <Tooltip content={<Tip fmt={(v) => pct(v, 2)} labelFmt={mesLabel} />} />
              <Line isAnimationActive={false} dataKey="devolucao" name="Devolução %" stroke={C.red} strokeWidth={2.2} dot={false} />
              <Line isAnimationActive={false} dataKey="cancelamento" name="Cancelamento %" stroke={C.violet} strokeWidth={2.2} dot={false} />
            </LineChart>
          </Chart>
        </Card>
        <Card title="Atendimento: tempo de resolução" sub={`Dias médios para fechar um chamado · meta ${META.metas.resolucao_dias} dias`}>
          <Chart h={240}>
            <LineChart data={x.mensal} margin={{ left: 0, right: 10, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="m" tickFormatter={mesLabel} {...axis} minTickGap={24} />
              <YAxis {...axis} width={40} tickFormatter={(v) => dec(v, 1)} />
              <ReferenceLine y={META.metas.resolucao_dias} stroke={C.mut} strokeDasharray="5 4" />
              <Tooltip content={<Tip fmt={(v) => `${dec(v)} dias`} labelFmt={mesLabel} />} />
              <Line isAnimationActive={false} dataKey="resolucao" name="Resolução" stroke={C.aqua} strokeWidth={2.4} dot={false} />
            </LineChart>
          </Chart>
        </Card>
      </div>

      <div className="grid g2 mt">
        {d4 && (
          <Card title="Rupturas de estoque no trimestre" sub={d4.indicador.leitura}>
            <div className="tbl"><table>
              <thead><tr>{d4.tabela.colunas.map((c, i) => <th key={c} className={i >= 2 ? 'r' : ''}>{c}</th>)}</tr></thead>
              <tbody>{d4.tabela.linhas.map((l, j) => (<tr key={j}>{l.map((v, i) => <td key={i} className={i >= 2 ? 'r' : ''}>{typeof v === 'number' && i >= 3 ? `R$ ${Math.round(v).toLocaleString('pt-BR')}` : v}</td>)}</tr>))}</tbody>
            </table></div>
          </Card>
        )}
        <Card title="Sazonalidade" sub="Índice de vendas por mês (1,00 = média do ano; base 2024–2025)">
          <Chart h={230}>
            <BarChart data={saz} margin={{ left: 0, right: 10, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="n" {...axis} />
              <YAxis {...axis} width={36} domain={[0, 'auto']} tickFormatter={(v) => dec(v, 1)} />
              <ReferenceLine y={1} stroke={C.mut} strokeDasharray="4 4" />
              <Tooltip content={<Tip fmt={(v) => dec(v, 2)} />} cursor={{ fill: '#ffffff10' }} />
              <Bar isAnimationActive={false} dataKey="indice" name="Índice" fill={C.blue} radius={[3, 3, 0, 0]} />
            </BarChart>
          </Chart>
        </Card>
      </div>
    </>
  )
}
