import { D, META } from '../calc'
import { Card } from '../ui/common'

const P = META.parametros
export default function Metodologia() {
  const erros = D.qualidade.filter((q) => q.severidade === 'erro')
  const infos = D.qualidade.filter((q) => q.severidade !== 'erro')
  return (
    <div className="meto">
      <div className="insight"><b>Dados simulados.</b> A empresa "{META.empresa}" e todos os números são fictícios, gerados com semente fixa para o projeto ser reproduzível. Os padrões (queda de margem, saída de vendedor, ruptura etc.) foram plantados de propósito e estão documentados e testados.</div>
      <div className="grid g2">
        <Card title="Definições dos indicadores">
          <ul>
            <li><b>Receita</b>: valor líquido (após desconto) dos pedidos não cancelados, no mês do pedido.</li>
            <li><b>Margem bruta %</b> = 1 − custo / receita.</li>
            <li><b>Desconto %</b> = 1 − receita / valor a preço de lista.</li>
            <li><b>OTD</b> = pedidos entregues na data prometida ou antes / pedidos entregues.</li>
            <li><b>Devolução %</b> = valor devolvido / receita.</li>
            <li><b>Ticket médio</b> = receita / pedidos não cancelados.</li>
            <li><b>Orçado e forecast</b> vêm da tabela <code>plano_mensal</code> (mês × região × linha).</li>
            <li>Comparações com o ano anterior usam o mesmo período (ex.: jan–set contra jan–set).</li>
          </ul>
        </Card>
        <Card title="Como o painel é calculado">
          <ul>
            <li>SQLite guarda os dados; as <i>views</i> em <code>sql/</code> calculam os indicadores.</li>
            <li>O painel recebe um cubo mensal por região × linha × segmento. Só entram somas, então qualquer filtro recalcula razões certas (margem, OTD) sem médias de médias.</li>
            <li>Clientes ativos são distintos e ficam fora do cubo, por isso não respondem ao filtro de linha.</li>
            <li>Recharts desenha os gráficos de linha, barra e dispersão; D3 faz a ponte (cascata) e o mapa de calor.</li>
          </ul>
        </Card>
      </div>
      <Card className="mt" title="Metas e gatilhos de decisão (tabela parametros)" sub="Mudar um valor aqui muda o alerta. Nada fica fixo no código do painel.">
        <div className="tbl"><table>
          <thead><tr><th>Parâmetro</th><th className="r">Valor</th></tr></thead>
          <tbody>{Object.entries(P).map(([k, v]) => <tr key={k}><td><code>{k}</code></td><td className="r">{v}</td></tr>)}</tbody>
        </table></div>
      </Card>
      <Card className="mt" title="Controles de qualidade dos dados" sub={`${erros.length} verificações de erro (devem ser 0) e ${infos.length} informativas`}>
        <div className="tbl"><table>
          <thead><tr><th>Verificação</th><th>Tipo</th><th className="r">Qtd</th></tr></thead>
          <tbody>{D.qualidade.map((q) => <tr key={q.verificacao}><td>{q.verificacao}</td><td>{q.severidade}</td><td className="r" style={{ color: q.severidade === 'erro' && q.qtd > 0 ? '#ff7b7b' : undefined }}>{q.qtd}</td></tr>)}</tbody>
        </table></div>
      </Card>
      <Card className="mt" title="Limites">
        <ul>
          <li>Dados simulados: não provam nada sobre o mundo real, mostram o método.</li>
          <li>Impactos "Estimado" dependem de premissas (ex.: recuperação de {Math.round(100 * +P.premissa_recuperacao)}% dos clientes em risco). Mude a premissa e o número muda.</li>
          <li>Associação não é causa: cada decisão diz o que ainda precisa ser confirmado antes de agir.</li>
        </ul>
      </Card>
    </div>
  )
}
