import { useMemo } from 'react'
import { ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, Cell } from 'recharts'
import { Card, Tip, Chart, Legend2, axis, C, cls } from '../ui/common'
import Waterfall from '../ui/Waterfall'
import { filtraCubo, filtraPlano, soma, kpis, serieMensal, agrupa, trimestre, ULTIMO_MES, META, D } from '../calc'
import { mi, brl, pct, dpct, dpp, compact, mesLabel, dec } from '../fmt'

const anoAnt = (a) => String(+a - 1)

function KpiCard({ nome, valor, trims, fmt, deltas }) {
  const max = Math.max(...trims.filter((v) => v != null), 1)
  return (
    <Card className="kpi">
      <div className="nome">{nome}</div>
      <div className="val">{valor}</div>
      <div className="q">
        {trims.map((v, i) => (
          <div key={i} title={v == null ? 'sem dados' : fmt(v)}>
            <i className={v == null ? 'off' : ''} style={{ height: v == null ? 2 : `${Math.max(8, (v / max) * 100)}%` }} />
            <span>FQ{i + 1}</span>
          </div>
        ))}
      </div>
      <div className="deltas">
        {deltas.map(([rot, txt, c]) => (
          <div key={rot}>{rot}<b className={c}>{txt}</b></div>
        ))}
      </div>
    </Card>
  )
}

export default function Executiva({ f }) {
  const d = useMemo(() => {
    const ano = f.ano
    const cubo = filtraCubo(f)
    const t = soma(cubo)
    const k = kpis(t)
    const plano = filtraPlano(f)
    const orc = plano.reduce((a, x) => a + x.bud, 0)
    const fc = plano.reduce((a, x) => a + x.fc, 0)
    const margemOrc = orc ? (100 * plano.reduce((a, x) => a + x.bud * x.bm, 0)) / orc : null
    // mesmo período do ano anterior (comparação justa quando o ano está em curso)
    const mesesAno = new Set(cubo.map((r) => r.m.slice(5)))
    const kAnt = kpis(soma(filtraCubo({ ...f, ano: anoAnt(ano) }).filter((r) => mesesAno.has(r.m.slice(5)))))
    const porTri = agrupa(cubo, (r) => trimestre(r.m))
    const tri = (fn) => [1, 2, 3, 4].map((q) => (porTri.has(q) ? fn(kpis(soma(porTri.get(q)))) : null))
    const serie = serieMensal(f).filter((s) => s.m.startsWith(ano))
    const regs = D.regioes.map((r) => {
      const c = soma(filtraCubo({ ...f, regiao: r }))
      const p = filtraPlano({ ...f, regiao: r })
      const o = p.reduce((a, x) => a + x.bud, 0), q = p.reduce((a, x) => a + x.fc, 0)
      return { r, rec: c.rec, orc: o, fc: q, vo: o ? 100 * (c.rec / o - 1) : null, vf: q ? 100 * (c.rec / q - 1) : null, mg: kpis(c).margem }
    }).filter((x) => x.rec > 0)
    return { k, kAnt, orc, fc, margemOrc, tri, serie, regs, t }
  }, [f])

  const { k, kAnt, orc, fc, margemOrc, tri, serie, regs } = d
  const vo = orc ? 100 * (k.receita / orc - 1) : null
  const vf = fc ? 100 * (k.receita / fc - 1) : null
  const fy = (v) => (v == null ? '–' : dpct(v))
  const crescimento = kAnt.receita ? 100 * (k.receita / kAnt.receita - 1) : null
  const pior = [...regs].filter((x) => x.vo != null).sort((a, b) => a.vo - b.vo)[0]
  const melhor = [...regs].filter((x) => x.vo != null).sort((a, b) => b.vo - a.vo)[0]
  const passos = regs.map((x) => ({ n: x.r, v: x.rec - x.orc }))
  const totOrc = regs.reduce((a, x) => a + x.orc, 0), totRec = regs.reduce((a, x) => a + x.rec, 0)
  const parcial = f.ano === ULTIMO_MES.slice(0, 4) && ULTIMO_MES.slice(5) !== '12'

  return (
    <>
      <div className="insight">
        <b>Leitura rápida · {f.ano}{parcial ? ` (até ${mesLabel(ULTIMO_MES)})` : ''}:</b> receita de {mi(k.receita)}, {dpct(vo)} vs orçado e {dpct(crescimento)} vs mesmo período de {anoAnt(f.ano)}.
        {melhor && pior && regs.length > 1 && <> {melhor.r} lidera ({dpct(melhor.vo)} vs orçado) e {pior.r} é a que mais fica atrás ({dpct(pior.vo)}).</>}
        {' '}Margem {pct(k.margem)} e entregas no prazo {pct(k.otd)} (meta {META.metas.otd}%). O que fazer com isso está em <b>Decisões</b>.
      </div>

      <div className="grid g4">
        <KpiCard nome="Receita líquida" valor={mi(k.receita)} trims={tri((x) => x.receita)} fmt={mi}
          deltas={[['vs Orçado', fy(vo), cls(vo)], ['vs Forecast', fy(vf), cls(vf)]]} />
        <KpiCard nome="Margem bruta" valor={pct(k.margem)} trims={tri((x) => x.margem)} fmt={pct}
          deltas={[['vs Orçado', dpp(k.margem - margemOrc), cls(k.margem - margemOrc)], [`vs ${anoAnt(f.ano)}`, dpp(k.margem - kAnt.margem), cls(k.margem - kAnt.margem)]]} />
        <KpiCard nome="Entregas no prazo (OTD)" valor={pct(k.otd)} trims={tri((x) => x.otd)} fmt={pct}
          deltas={[['vs Meta', dpp(k.otd - META.metas.otd), cls(k.otd - META.metas.otd)], [`vs ${anoAnt(f.ano)}`, dpp(k.otd - kAnt.otd), cls(k.otd - kAnt.otd)]]} />
        <KpiCard nome="Ticket médio" valor={brl(k.ticket)} trims={tri((x) => x.ticket)} fmt={brl}
          deltas={[[`vs ${anoAnt(f.ano)}`, fy(kAnt.ticket ? 100 * (k.ticket / kAnt.ticket - 1) : null), cls(k.ticket - kAnt.ticket)], ['Pedidos', compact(k.pedidos), '']]} />
      </div>

      <div className="grid g32 mt">
        <Card title="Receita: realizado, orçado e forecast" sub="Mensal, R$">
          <Legend2 items={[[C.blue, 'Realizado'], [C.orange, 'Orçado'], [C.violet, 'Forecast']]} />
          <Chart h={270}>
            <ComposedChart data={serie} margin={{ left: 0, right: 8, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="m" tickFormatter={mesLabel} {...axis} />
              <YAxis tickFormatter={compact} {...axis} width={52} />
              <Tooltip content={<Tip fmt={(v) => brl(v)} labelFmt={mesLabel} />} />
              <Area isAnimationActive={false} dataKey="receita" name="Realizado" stroke={C.blue} fill={C.blue} fillOpacity={0.2} strokeWidth={2.4} />
              <Line isAnimationActive={false} dataKey="orcado" name="Orçado" stroke={C.orange} strokeDasharray="6 4" dot={false} strokeWidth={2} />
              <Line isAnimationActive={false} dataKey="forecast" name="Forecast" stroke={C.violet} dot={false} strokeWidth={2} />
            </ComposedChart>
          </Chart>
        </Card>
        <Card title="Receita por região" sub="Realizado vs orçado, R$">
          <Legend2 items={[[C.blue, 'Realizado'], [C.orange, 'Orçado']]} />
          <Chart h={270}>
            <BarChart data={regs} layout="vertical" margin={{ left: 6, right: 14 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" horizontal={false} />
              <XAxis type="number" tickFormatter={compact} {...axis} />
              <YAxis type="category" dataKey="r" {...axis} width={86} />
              <Tooltip content={<Tip fmt={(v) => brl(v)} />} cursor={{ fill: '#ffffff10' }} />
              <Bar isAnimationActive={false} dataKey="rec" name="Realizado" fill={C.blue} radius={[0, 3, 3, 0]} />
              <Bar isAnimationActive={false} dataKey="orc" name="Orçado" fill={C.orange} radius={[0, 3, 3, 0]} />
            </BarChart>
          </Chart>
        </Card>
      </div>

      <div className="grid g2 mt">
        <Card title="Desempenho por região" sub="Variação da receita contra orçado e forecast">
          <div className="tbl">
            <table>
              <thead><tr><th>Região</th><th className="r">Receita</th><th className="r">vs Orçado</th><th className="r">vs Forecast</th><th className="r">Margem</th></tr></thead>
              <tbody>
                {regs.map((x) => (
                  <tr key={x.r}><td>{x.r}</td><td className="r">{mi(x.rec)}</td>
                    <td className={`r ${cls(x.vo)}`}>{fy(x.vo)}</td><td className={`r ${cls(x.vf)}`}>{fy(x.vf)}</td><td className="r">{pct(x.mg)}</td></tr>
                ))}
                <tr className="tot"><td>Total</td><td className="r">{mi(totRec)}</td><td className={`r ${cls(vo)}`}>{fy(vo)}</td><td className={`r ${cls(vf)}`}>{fy(vf)}</td><td className="r">{pct(k.margem)}</td></tr>
              </tbody>
            </table>
          </div>
        </Card>
        <Card title="Ponte: do orçado ao realizado" sub="Quanto cada região somou ou tirou do resultado">
          <Waterfall orcado={totOrc} passos={passos} realizado={totRec} />
        </Card>
      </div>
    </>
  )
}
