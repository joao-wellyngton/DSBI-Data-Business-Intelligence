import { useMemo } from 'react'
import { ComposedChart, Line, Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, ScatterChart, Scatter, ZAxis, Cell, ReferenceLine, LineChart } from 'recharts'
import { Card, Tip, Chart, Legend2, axis, C } from '../ui/common'
import { filtraCubo, soma, kpis, agrupa, ativosMedios, D } from '../calc'
import { mi, pct, brl, dec, int, compact, mesLabel } from '../fmt'

export default function Comercial({ f }) {
  const x = useMemo(() => {
    const base = filtraCubo(f)
    const por = (chave) => [...agrupa(base, chave).entries()].map(([n, rs]) => ({ n, ...kpis(soma(rs)) }))
    const linhas = por((r) => r.l).sort((a, b) => b.receita - a.receita)
    const segs = por((r) => r.s).sort((a, b) => b.receita - a.receita)
    const pts = [...agrupa(base, (r) => r.r + '|' + r.l).entries()].map(([k, rs]) => ({ n: k.replace('|', ' · '), ...kpis(soma(rs)) }))
    const mensal = [...agrupa(filtraCubo({ ...f, ano: null }), (r) => r.m).entries()].sort().map(([m, rs]) => ({ m, ...kpis(soma(rs)) }))
    const ativos = ativosMedios({ regiao: f.regiao })
    return { linhas, segs, pts, mensal, ativos }
  }, [f])
  const d1 = D.decisoes.find((d) => d.id === 'D1')
  const conc = D.concentracao.slice(0, 10)
  const margMed = x.pts.length ? x.pts.reduce((a, p) => a + p.margem, 0) / x.pts.length : 0
  const ped = [...D.vendedores].sort((a, b) => b.receita - a.receita)

  return (
    <>
      <div className="grid g2">
        <Card title="Receita e margem por linha de produto" sub={`${f.ano}${f.regiao ? ' · ' + f.regiao : ''}`}>
          <div className="tbl"><table>
            <thead><tr><th>Linha</th><th className="r">Receita</th><th className="r">Margem</th><th className="r">Desconto</th><th className="r">Ticket</th></tr></thead>
            <tbody>{x.linhas.map((l) => (<tr key={l.n}><td>{l.n}</td><td className="r">{mi(l.receita)}</td><td className="r">{pct(l.margem)}</td><td className="r">{pct(l.desconto)}</td><td className="r">{brl(l.ticket)}</td></tr>))}</tbody>
          </table></div>
        </Card>
        <Card title="Receita por segmento de cliente" sub="R$ no período filtrado">
          <Chart h={210}>
            <BarChart data={x.segs} layout="vertical" margin={{ left: 6, right: 16 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" horizontal={false} />
              <XAxis type="number" tickFormatter={compact} {...axis} />
              <YAxis type="category" dataKey="n" {...axis} width={70} />
              <Tooltip content={<Tip fmt={(v) => brl(v)} />} cursor={{ fill: '#ffffff10' }} />
              <Bar isAnimationActive={false} dataKey="receita" name="Receita" fill={C.blue} radius={[0, 3, 3, 0]} />
            </BarChart>
          </Chart>
        </Card>
      </div>

      <div className="grid g2 mt">
        <Card title="Desconto x margem" sub="Cada ponto é uma combinação região · linha. Desconto maior deveria vir com margem menor; pontos abaixo do grupo merecem olhar.">
          <Chart h={280}>
            <ScatterChart margin={{ left: 0, right: 14, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" />
              <XAxis type="number" dataKey="desconto" name="Desconto" unit="%" {...axis} domain={['dataMin - 1', 'dataMax + 1']} tickFormatter={(v) => dec(v, 0)} />
              <YAxis type="number" dataKey="margem" name="Margem" unit="%" {...axis} domain={['dataMin - 1', 'dataMax + 1']} tickFormatter={(v) => dec(v, 0)} width={40} />
              <ZAxis type="number" dataKey="receita" range={[40, 360]} name="Receita" />
              <ReferenceLine y={margMed} stroke={C.mut} strokeDasharray="4 4" />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => active && payload?.length ? (
                <div className="tt"><b>{payload[0].payload.n}</b>Desconto {pct(payload[0].payload.desconto)}<br />Margem {pct(payload[0].payload.margem)}<br />Receita {mi(payload[0].payload.receita)}</div>) : null} />
              <Scatter isAnimationActive={false} data={x.pts} fill={C.violet} fillOpacity={0.75} />
            </ScatterChart>
          </Chart>
          <div className="note">Linha tracejada = margem média dos pontos ({pct(margMed)}).</div>
        </Card>
        <Card title="Clientes ativos por mês" sub="Clientes distintos que compraram no mês (não é filtrado por linha)">
          <Chart h={280}>
            <LineChart data={x.ativos} margin={{ left: 0, right: 10, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="m" tickFormatter={mesLabel} {...axis} minTickGap={24} />
              <YAxis {...axis} width={40} domain={['auto', 'auto']} />
              <Tooltip content={<Tip labelFmt={mesLabel} />} />
              <Line isAnimationActive={false} dataKey="ativos" name="Clientes ativos" stroke={C.aqua} strokeWidth={2.4} dot={false} />
            </LineChart>
          </Chart>
        </Card>
      </div>

      <div className="grid g2 mt">
        <Card title="Concentração: 10 maiores clientes" sub="% da receita total · coluna = cliente, linha = acumulado (12 meses)">
          <Chart h={260}>
            <ComposedChart data={conc.map((c) => ({ ...c, ac: conc.filter((z) => z.rk <= c.rk).reduce((a, z) => a + z.pct, 0) }))} margin={{ left: 0, right: 10, top: 6 }}>
              <CartesianGrid stroke={C.grid} strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="rk" {...axis} tickFormatter={(v) => `#${v}`} />
              <YAxis {...axis} width={40} tickFormatter={(v) => `${dec(v, 0)}%`} />
              <Tooltip content={<Tip fmt={(v) => pct(v, 2)} labelFmt={(v) => `Cliente #${v}`} />} />
              <Bar isAnimationActive={false} dataKey="pct" name="% da receita" fill={C.blue} radius={[3, 3, 0, 0]} />
              <Line isAnimationActive={false} dataKey="ac" name="% acumulado" stroke={C.orange} strokeWidth={2.2} dot={{ r: 2 }} />
            </ComposedChart>
          </Chart>
          <div className="note">Os 10 maiores somam {pct(conc.reduce((a, c) => a + c.pct, 0))} da receita. Gatilho de atenção: {pct(100 * +D.meta.parametros.gatilho_concentracao, 0)} do total nos 10 maiores.</div>
        </Card>
        <Card title="Vendedores: desconto e margem (12 meses)" sub="Z-score = distância do desconto médio do time. Acima de 1,5 chama atenção.">
          <div className="tbl"><table>
            <thead><tr><th>Vendedor</th><th>Região</th><th className="r">Receita</th><th className="r">Desc.</th><th className="r">Margem</th><th className="r">Z</th></tr></thead>
            <tbody>{ped.slice(0, 12).map((v) => (
              <tr key={v.vendedor_id}><td>{v.vendedor_id} · {v.nome}</td><td>{v.regiao}</td><td className="r">{mi(v.receita)}</td><td className="r">{pct(v.desconto_pct)}</td><td className="r">{pct(v.margem_pct)}</td>
                <td className="r" style={{ color: v.z >= +D.meta.parametros.gatilho_vendedor_z ? '#ff7b7b' : undefined, fontWeight: v.z >= 1.5 ? 700 : 400 }}>{dec(v.z)}</td></tr>))}</tbody>
          </table></div>
        </Card>
      </div>

      {d1 && (
        <Card className="mt" title="Clientes em risco de abandono" sub={d1.indicador.leitura}>
          <div className="tbl"><table>
            <thead><tr>{d1.tabela.colunas.map((c, i) => <th key={c} className={i >= 4 ? 'r' : ''}>{c}</th>)}</tr></thead>
            <tbody>{d1.tabela.linhas.map((l, j) => (<tr key={j}>{l.map((v, i) => <td key={i} className={i >= 4 ? 'r' : ''}>{i === 5 ? brl(v) : i === 4 ? int(v) : v}</td>)}</tr>))}</tbody>
          </table></div>
          <div className="note">Lista completa de quem procurar primeiro está na decisão D1.</div>
        </Card>
      )}
    </>
  )
}
