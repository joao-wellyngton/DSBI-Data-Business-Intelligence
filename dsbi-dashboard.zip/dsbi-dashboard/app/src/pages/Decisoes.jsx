import { useState } from 'react'
import { D } from '../calc'
import { Card } from '../ui/common'
import { brl, int } from '../fmt'

const PILL = { 'Agir agora': 'p-agir', Investigar: 'p-inv', Planejar: 'p-plan', Monitorar: 'p-mon' }
const fmtCel = (v) => (typeof v === 'number' ? (Math.abs(v) >= 10000 ? brl(v) : Number.isInteger(v) ? int(v) : v.toLocaleString('pt-BR', { maximumFractionDigits: 2 })) : v)

export default function Decisoes() {
  const [abertas, setAbertas] = useState({})
  const resumo = ['Agir agora', 'Investigar', 'Planejar', 'Monitorar'].map((s) => [s, D.decisoes.filter((d) => d.status === s).length])
  const totalObs = D.decisoes.filter((d) => d.impacto.tipo === 'Estimado').reduce((a, d) => a + (d.impacto.valor || 0), 0)
  return (
    <>
      <div className="insight">
        <b>Como ler:</b> cada cartão parte de um indicador, mostra o gatilho que o disparou, separa o que é evidência do que é hipótese, e termina com uma ação, um dono, um prazo e o que acompanhar.
        Nem todo alerta vira ação: há casos de <b>Monitorar</b> e <b>Planejar</b>. Valores marcados <b>Estimado</b> dependem de uma premissa escrita no cartão; <b>Observado</b> vem direto dos dados.
        <div style={{ marginTop: 6 }}>{resumo.map(([s, n]) => <span key={s} className={`pill ${PILL[s]}`} style={{ marginRight: 8 }}>{s}: {n}</span>)}</div>
      </div>
      {D.decisoes.map((d) => (
        <Card key={d.id} className="dec">
          <div className="hd">
            <span className="id">{d.id} · {d.area}</span>
            <span className={`pill ${PILL[d.status]}`}>{d.status}</span>
            <h3>{d.titulo}</h3>
          </div>
          <div className="sub" style={{ margin: '6px 0 0' }}>{d.pergunta}</div>
          <div className="flow">
            <div><h4>1 · Indicador</h4><span className="big">{d.indicador.nome}</span>{d.indicador.valor}</div>
            <div><h4>2 · Gatilho</h4>{d.indicador.gatilho}<div className="note" style={{ marginTop: 4 }}>{d.indicador.leitura}</div></div>
            <div><h4>3 · Decisão</h4>{d.acao}</div>
            <div><h4>4 · Dono e prazo</h4><span className="big">{d.prazo}</span>{d.responsavel}</div>
            <div><h4>5 · Acompanhar</h4>{d.acompanhar}<div className="note" style={{ marginTop: 4 }}>Revisar se: {d.revisar_se}</div></div>
          </div>
          <div className="cols">
            <div>
              <h4>O que os dados mostram</h4>
              <ul>{d.sinais.map((s) => <li key={s.r}>{s.r}: <b>{s.v}</b></li>)}</ul>
              <h4>Força da evidência: {d.evidencia.nivel}</h4>
              <div style={{ fontSize: 13, lineHeight: 1.5 }}>{d.evidencia.porque}</div>
            </div>
            <div>
              <h4>Outras explicações possíveis</h4>
              <ul>{d.alternativas.map((a) => <li key={a}>{a}</li>)}</ul>
              <div className="imp">
                <b>{d.impacto.rotulo}</b><span className="tag">{d.impacto.tipo}</span>
                <div>{d.impacto.texto}</div>
                {d.impacto.premissa && <div className="note">Premissa: {d.impacto.premissa}</div>}
              </div>
            </div>
          </div>
          {d.tabela && (
            <details open={!!abertas[d.id]} onToggle={(e) => setAbertas({ ...abertas, [d.id]: e.target.open })}>
              <summary>Ver dados de apoio ({d.tabela.linhas.length} linhas)</summary>
              <div className="tbl"><table>
                <thead><tr>{d.tabela.colunas.map((c, i) => <th key={c} className={i > 0 ? 'r' : ''}>{c}</th>)}</tr></thead>
                <tbody>{d.tabela.linhas.map((l, j) => <tr key={j}>{l.map((v, i) => <td key={i} className={i > 0 ? 'r' : ''}>{fmtCel(v)}</td>)}</tr>)}</tbody>
              </table></div>
            </details>
          )}
        </Card>
      ))}
    </>
  )
}
