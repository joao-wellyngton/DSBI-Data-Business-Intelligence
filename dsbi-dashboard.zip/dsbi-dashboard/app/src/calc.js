import D from './data.json'

export const META = D.meta
export const ULTIMO_MES = D.meta.periodo[1]
export const ANOS = [...new Set(D.cubo.map((r) => r.m.slice(0, 4)))].sort()

const Z = () => ({ rec: 0, cus: 0, bru: 0, ped: 0, pt: 0, can: 0, ent: 0, np: 0, lt: 0, at: 0, dev: 0, ch: 0, chr: 0, rd: 0 })

export function soma(rows) {
  const t = Z()
  for (const r of rows) for (const k in t) t[k] += r[k]
  return t
}

// KPIs derivados de uma soma do cubo (mesmas fórmulas de sql/02_kpis.sql)
export function kpis(t) {
  return {
    receita: t.rec,
    margem: t.rec ? 100 * (1 - t.cus / t.rec) : null,
    desconto: t.bru ? 100 * (1 - t.rec / t.bru) : null,
    pedidos: t.ped,
    ticket: t.ped ? t.rec / t.ped : null,
    otd: t.ent ? (100 * t.np) / t.ent : null,
    devolucao: t.rec ? (100 * t.dev) / t.rec : null,
    cancelamento: t.pt ? (100 * t.can) / t.pt : null,
    leadtime: t.ent ? t.lt / t.ent : null,
    atraso: t.ent - t.np ? t.at / (t.ent - t.np) : null,
    resolucao: t.chr ? t.rd / t.chr : null,
    chamados: t.ch,
    chamadosPct: t.ped ? (100 * t.ch) / t.ped : null,
  }
}

export const trimestre = (ym) => Math.ceil(+ym.slice(5, 7) / 3)

export function filtraCubo({ ano, regiao, linha, segmento }) {
  return D.cubo.filter(
    (r) =>
      (!ano || r.m.startsWith(ano)) &&
      (!regiao || r.r === regiao) &&
      (!linha || r.l === linha) &&
      (!segmento || r.s === segmento),
  )
}

export function filtraPlano({ ano, regiao, linha }) {
  return D.plano.filter(
    (p) => p.m <= ULTIMO_MES && (!ano || p.m.startsWith(ano)) && (!regiao || p.r === regiao) && (!linha || p.l === linha),
  )
}

export const agrupa = (rows, chave) => {
  const m = new Map()
  for (const r of rows) {
    const k = chave(r)
    if (!m.has(k)) m.set(k, [])
    m.get(k).push(r)
  }
  return m
}

// Série mensal: realizado (cubo) + orçado + forecast (plano) alinhados por mês
export function serieMensal(f) {
  const cubo = agrupa(filtraCubo({ ...f, ano: null }), (r) => r.m)
  const plano = agrupa(filtraPlano({ ...f, ano: null }), (p) => p.m)
  const meses = [...cubo.keys()].sort()
  return meses.map((m) => {
    const t = soma(cubo.get(m))
    const p = plano.get(m) || []
    return {
      m,
      ...kpis(t),
      orcado: p.reduce((a, x) => a + x.bud, 0),
      forecast: p.reduce((a, x) => a + x.fc, 0),
      margemOrc: p.length ? (100 * p.reduce((a, x) => a + x.bud * x.bm, 0)) / p.reduce((a, x) => a + x.bud, 0) : null,
    }
  })
}

export function ativosMedios(f) {
  // clientes ativos distintos são somados por região x segmento (ativos não é aditivo entre meses)
  const rows = D.ativos.filter((a) => (!f.regiao || a.r === f.regiao) && (!f.segmento || a.s === f.segmento))
  const m = agrupa(rows, (a) => a.m)
  return [...m.entries()].sort().map(([k, v]) => ({ m: k, ativos: v.reduce((a, x) => a + x.a, 0) }))
}

export { D }
