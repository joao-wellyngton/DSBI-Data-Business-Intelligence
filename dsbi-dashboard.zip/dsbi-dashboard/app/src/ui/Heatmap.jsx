import * as d3 from 'd3'
import { mesLabel, dec } from '../fmt'

// Mapa de calor região x mês (D3 só para escalas; o SVG é desenhado pelo React)
export default function Heatmap({ meses, regioes, valor, meta, destaque }) {
  const W = 960, ml = 96, mt = 22, ch = 30, H = mt + regioes.length * ch + 8
  const cw = (W - ml - 6) / meses.length
  const cor = d3
    .scaleLinear()
    .domain([82, meta, 98])
    .range(['#c4503f', '#4a5578', '#1fae7e'])
    .clamp(true)
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="OTD por região e mês">
      {meses.map((m, i) =>
        i % 3 === 0 ? (
          <text key={m} x={ml + i * cw + cw / 2} y={14} fontSize="10" fill="#9aa6c4" textAnchor="middle">{mesLabel(m)}</text>
        ) : null,
      )}
      {regioes.map((r, j) => (
        <g key={r} opacity={destaque && destaque !== r ? 0.45 : 1}>
          <text x={ml - 8} y={mt + j * ch + ch / 2 + 4} fontSize="12" fill="#e8ecf6" textAnchor="end">{r}</text>
          {meses.map((m, i) => {
            const v = valor(r, m)
            return (
              <rect key={m} x={ml + i * cw + 1} y={mt + j * ch + 1} width={cw - 2} height={ch - 2} rx="3" fill={v == null ? '#2b3552' : cor(v)}>
                <title>{`${r} · ${mesLabel(m)}: ${v == null ? 'sem entregas' : dec(v) + '% no prazo'}`}</title>
              </rect>
            )
          })}
        </g>
      ))}
    </svg>
  )
}
