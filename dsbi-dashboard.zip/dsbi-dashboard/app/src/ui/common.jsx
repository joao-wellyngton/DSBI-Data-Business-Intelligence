import { ResponsiveContainer } from 'recharts'

export const C = { blue: '#3987e5', aqua: '#199e70', orange: '#d95926', violet: '#9085e9', red: '#e66767', mut: '#9aa6c4', grid: '#3a4565' }
export const axis = { stroke: C.mut, fontSize: 11, tickLine: false }

export function Card({ title, sub, children, className = '' }) {
  return (
    <div className={`card ${className}`}>
      {title && <h3>{title}</h3>}
      {sub && <div className="sub">{sub}</div>}
      {children}
    </div>
  )
}

export function Tip({ active, payload, label, fmt = (v) => v, labelFmt = (l) => l }) {
  if (!active || !payload?.length) return null
  return (
    <div className="tt">
      <b>{labelFmt(label)}</b>
      {payload.filter((p) => p.value != null).map((p) => (
        <div key={p.dataKey + p.name}>
          <span style={{ color: p.color || p.stroke || p.fill }}>● </span>
          {p.name}: {fmt(p.value, p.dataKey)}
        </div>
      ))}
    </div>
  )
}

export const Chart = ({ h = 260, children }) => (
  <ResponsiveContainer width="100%" height={h}>
    {children}
  </ResponsiveContainer>
)

export const Legend2 = ({ items }) => (
  <div className="legend">
    {items.map(([c, t]) => (
      <span key={t}><i style={{ background: c }} />{t}</span>
    ))}
  </div>
)

export const cls = (v, goodUp = true) => (v == null ? '' : (v >= 0) === goodUp ? 'up' : 'down')
