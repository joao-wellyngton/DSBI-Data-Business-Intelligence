import * as d3 from 'd3'
import { compact } from '../fmt'

// Ponte Orçado -> Realizado por região (cascata)
export default function Waterfall({ orcado, passos, realizado }) {
  const W = 760, H = 280, m = { t: 20, r: 10, b: 44, l: 52 }
  const itens = [{ n: 'Orçado', v: orcado, tipo: 'tot' }, ...passos.map((p) => ({ n: p.n, v: p.v, tipo: 'var' })), { n: 'Realizado', v: realizado, tipo: 'tot' }]
  let acc = orcado
  const meio = passos.map((p) => { const y0 = acc; acc += p.v; return Math.min(y0, acc) })
  const base = Math.min(orcado, realizado, ...meio) * 0.97
  acc = 0
  const barras = itens.map((it) => {
    if (it.tipo === 'tot') { acc = it.v; return { ...it, y0: base, y1: it.v } }
    const y0 = acc; acc += it.v; return { ...it, y0, y1: acc }
  })
  const hi = Math.max(...barras.map((b) => Math.max(b.y0, b.y1)))
  const x = d3.scaleBand().domain(barras.map((b) => b.n)).range([m.l, W - m.r]).padding(0.25)
  const y = d3.scaleLinear().domain([base, hi * 1.02]).range([H - m.b, m.t])
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Ponte orçado para realizado por região">
      {y.ticks(4).map((t) => (
        <g key={t}>
          <line x1={m.l} x2={W - m.r} y1={y(t)} y2={y(t)} stroke="#3a4565" strokeDasharray="3 4" />
          <text x={m.l - 6} y={y(t) + 4} fontSize="10" fill="#9aa6c4" textAnchor="end">{compact(t)}</text>
        </g>
      ))}
      {barras.map((b, i) => {
        const top = y(Math.max(b.y0, b.y1)), bot = y(Math.min(b.y0, b.y1))
        const cor = b.tipo === 'tot' ? '#3987e5' : b.v >= 0 ? '#199e70' : '#e66767'
        return (
          <g key={b.n}>
            <rect x={x(b.n)} y={top} width={x.bandwidth()} height={Math.max(bot - top, 2)} rx="3" fill={cor} />
            <text x={x(b.n) + x.bandwidth() / 2} y={top - 5} fontSize="11" fill="#e8ecf6" textAnchor="middle">
              {b.tipo === 'tot' ? compact(b.v) : (b.v >= 0 ? '+' : '−') + compact(Math.abs(b.v))}
            </text>
            <text x={x(b.n) + x.bandwidth() / 2} y={H - m.b + 16} fontSize="11" fill="#9aa6c4" textAnchor="middle">{b.n}</text>
            {i < barras.length - 1 && (
              <line x1={x(b.n) + x.bandwidth()} x2={x(barras[i + 1].n)} y1={y(b.y1)} y2={y(b.y1)} stroke="#9aa6c4" strokeWidth="0.8" />
            )}
          </g>
        )
      })}
      <text x={m.l} y={H - 6} fontSize="10" fill="#9aa6c4">Eixo começa em {compact(base)} para destacar as diferenças</text>
    </svg>
  )
}
