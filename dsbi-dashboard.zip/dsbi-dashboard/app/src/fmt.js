const n0 = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 0 })
const n1 = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })
const n2 = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })

export const int = (v) => (v == null || isNaN(v) ? '–' : n0.format(v))
export const dec = (v, d = 1) => (v == null || isNaN(v) ? '–' : (d === 2 ? n2 : n1).format(v))
export const pct = (v, d = 1) => (v == null || isNaN(v) ? '–' : `${dec(v, d)}%`)
export const dpct = (v) => (v == null || isNaN(v) ? '–' : `${v >= 0 ? '+' : '−'}${n1.format(Math.abs(v))}%`)
export const dpp = (v) => (v == null || isNaN(v) ? '–' : `${v >= 0 ? '+' : '−'}${n1.format(Math.abs(v))} pp`)
export const brl = (v) => (v == null || isNaN(v) ? '–' : `R$ ${n0.format(v)}`)
export const mi = (v) => (v == null || isNaN(v) ? '–' : `R$ ${n1.format(v / 1e6)} mi`)
export const compact = (v) => {
  if (v == null || isNaN(v)) return '–'
  const a = Math.abs(v)
  if (a >= 1e6) return `${n1.format(v / 1e6)} mi`
  if (a >= 1e3) return `${n0.format(v / 1e3)} mil`
  return n0.format(v)
}
export const MESES = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez']
export const mesLabel = (ym) => `${MESES[+ym.slice(5, 7) - 1]}/${ym.slice(2, 4)}`
