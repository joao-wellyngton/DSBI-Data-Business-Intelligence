import { useState } from 'react'
import { D, ANOS, META, ULTIMO_MES } from './calc'
import { mesLabel } from './fmt'
import Executiva from './pages/Executiva'
import Comercial from './pages/Comercial'
import Operacoes from './pages/Operacoes'
import Decisoes from './pages/Decisoes'
import Metodologia from './pages/Metodologia'

const PAGINAS = [
  ['exec', 'Visão executiva', Executiva],
  ['com', 'Comercial', Comercial],
  ['ops', 'Operações', Operacoes],
  ['dec', 'Decisões', Decisoes],
  ['met', 'Metodologia', Metodologia],
]
const INICIAL = { ano: ANOS[ANOS.length - 1], regiao: '', linha: '' }

export default function App() {
  const [pg, setPg] = useState('exec')
  const [f, setF] = useState(INICIAL)
  const [, titulo, Page] = PAGINAS.find((p) => p[0] === pg)
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const filtros = pg !== 'dec' && pg !== 'met'
  const nAgir = D.decisoes.filter((d) => d.status === 'Agir agora').length
  return (
    <div className="app">
      <aside className="side">
        <div className="brand">DSBI<small>{META.empresa}</small></div>
        {PAGINAS.map(([k, t]) => (
          <button key={k} className={`nav ${pg === k ? 'on' : ''}`} onClick={() => setPg(k)}>
            {t}{k === 'dec' && nAgir ? ` (${nAgir})` : ''}
          </button>
        ))}
        <div className="sp" />
        <button className="reset" onClick={() => setF(INICIAL)}>Limpar filtros</button>
        <div className="simul">Dados simulados · base até {mesLabel(ULTIMO_MES)}</div>
      </aside>
      <main className="main">
        <div className="top">
          <h1>{titulo}<small>Do indicador à decisão · {META.empresa}</small></h1>
          {filtros && (
            <div className="filters">
              <label>Ano<select value={f.ano} onChange={set('ano')}>{ANOS.map((a) => <option key={a}>{a}</option>)}</select></label>
              <label>Região<select value={f.regiao} onChange={set('regiao')}><option value="">Todas</option>{D.regioes.map((r) => <option key={r}>{r}</option>)}</select></label>
              <label>Linha<select value={f.linha} onChange={set('linha')}><option value="">Todas</option>{D.linhas.map((l) => <option key={l}>{l}</option>)}</select></label>
            </div>
          )}
        </div>
        <Page f={f} />
      </main>
    </div>
  )
}
