# DSBI — Data & Business Intelligence

Painel de indicadores comerciais e operacionais para responder:

> **Como transformar dados dispersos em indicadores que ajudem gestores a tomar decisões?**

**Ferramentas:** SQL · SQLite · Python (pandas) · React · Recharts · D3

![Pipeline](docs/diagrama_pipeline.png)

📄 **[Relatório completo](docs/RELATORIO.md)** ([PDF](docs/Relatorio_DSBI.pdf)) — passo a passo, problemas resolvidos e limites.  
🎞️ **[Apresentação em PDF](docs/Apresentacao_DSBI.pdf)** — 10 slides com capturas do painel.  
🖥️ **[Abrir o painel](dashboard/index.html)** — 1 arquivo, funciona offline (baixe e abra).

![Visão executiva](docs/painel_executivo.png)
![Decisões](docs/painel_decisoes.png)

> ⚠️ **Os dados são SIMULADOS.** "Vertix Distribuidora" é fictícia. Os números foram gerados com semente fixa (reprodutíveis) e trazem padrões plantados de propósito (queda de margem, saída de vendedor, ruptura etc.) para o método poder ser testado. Nada aqui descreve uma empresa real.

## Diferencial: indicador → decisão
O painel não para no gráfico. Cada alerta vira um cartão com:
1. **Indicador** e **gatilho** (os limites ficam na tabela `parametros`, não no código);
2. **Evidência** (Forte/Moderada) e **outras explicações possíveis**;
3. **Ação, dono e prazo**;
4. **Impacto** marcado como *Observado* ou *Estimado* (com a premissa escrita);
5. **O que acompanhar** e **quando revisar a decisão**.

Nem todo alerta pede ação: há cartões de **Monitorar** e **Planejar**.

| Decisão | Status | Indicador |
|---|---|---|
| D1 Clientes que pararam de comprar | Agir agora | R$ 11,7 mi de receita em risco (13,4% da receita 12m) |
| D2 Margem de Eletrônicos | Agir agora | 9,5% (era 14,1%), desconto subiu |
| D4 Rupturas de estoque | Agir agora | 6 produtos com ≥ 5 dias sem estoque |
| D5 Desconto de vendedores | Investigar | V03 13,2% e V09 11,5% contra ~7% |
| D3 Entregas no Nordeste | Investigar | OTD 75,2% (era 86,1%) |
| D7 Pico de nov/dez | Planejar | índice 1,24 e 1,38 |
| D6 Dependência de grandes clientes | Monitorar | top 10 = 11,2% (gatilho 25%) |

## Resultados na base simulada
- 31.007 pedidos · 97.843 itens · R$ 217,3 mi · 620 clientes · 12 vendedores · jan/2024 a set/2026
- 2026 (até set): receita R$ 62,0 mi, −2,1% vs orçado; margem 21,9%; OTD 90,5% (meta 92%)
- 10 controles de qualidade de erro, todos em 0; testes automáticos passam

## Estrutura
```
src/
  gerar_dados.py     gera data/dsbi.db (seed 7, reprodutível; não vai pro Git, é gerado)
  exportar_json.py   roda as views, monta os cartões de decisão, grava app/src/data.json
  testes.py          integridade, totais do cubo = SQL, histórias plantadas, cartões completos
  gerar_diagrama.py  gera docs/diagrama_pipeline.svg/png
  gerar_pdf.py       relatório em PDF (precisa de markdown e playwright)
  gerar_apresentacao.py  apresentação em PDF com capturas do painel (playwright)
  build_dsbi.py      roda tudo em ordem
sql/
  01_schema.sql      tabelas e índices
  02_kpis.sql        cubo mensal e KPIs (receita, margem, desconto, OTD, devolução)
  03_decisoes.sql    views de risco, margem, OTD, ruptura, desconto, concentração, sazonalidade
  04_qualidade.sql   controles de qualidade
app/                 React + Vite + Recharts + D3 (código-fonte do painel)
dashboard/index.html painel pronto, 1 arquivo, abre offline
docs/                relatório, apresentação (PDFs), diagrama e capturas
```

## Como rodar
```bash
pip install -r requirements.txt
python src/build_dsbi.py            # dados → SQL → JSON → testes → painel
open dashboard/index.html           # macOS (Windows: start / Linux: xdg-open)
```
Só quer ver? Abra `dashboard/index.html` direto. Para desenvolver: `cd app && npm install && npm run dev`.

## Usar dados reais
1. Carregue suas tabelas no mesmo formato de `sql/01_schema.sql` (pedidos, itens, clientes, vendedores, devoluções, chamados, estoque, plano e parâmetros).
2. Ajuste metas e gatilhos na tabela `parametros`.
3. Rode `python src/exportar_json.py && python src/testes.py` e depois `npm run build` em `app/`.

## Limites
- Dados simulados: o projeto mostra o **método**, não resultados do mundo real.
- Impactos "Estimado" dependem de premissas (ex.: recuperar 30% dos clientes em risco).
- Associação não é causa: cada cartão diz o que ainda precisa ser confirmado.
- Clientes ativos são contagem distinta, por isso não respondem ao filtro de linha.

## Licença
MIT — veja [LICENSE](LICENSE).
