/* =====================================================================
   02 - KPIs COMERCIAIS E OPERACIONAIS (SQLite)
   Base de tudo que aparece no painel. Definições:
     Receita        = valor líquido (após desconto) dos pedidos não cancelados, no mês do pedido
     Margem bruta % = 1 - custo / receita
     Desconto %     = 1 - receita / valor a preço de lista
     OTD            = pedidos entregues na data prometida ou antes / pedidos entregues
     Devolução %    = valor devolvido / receita
   ===================================================================== */
DROP VIEW IF EXISTS vw_pedidos;
DROP VIEW IF EXISTS vw_cubo_mensal;
DROP VIEW IF EXISTS vw_ativos_mensal;
DROP VIEW IF EXISTS vw_kpi_mensal;
DROP VIEW IF EXISTS vw_real_vs_plano;
DROP VIEW IF EXISTS vw_kpi_regiao_ano;

CREATE VIEW vw_pedidos AS
SELECT p.*,
       substr(p.data_pedido, 1, 7)                       AS ano_mes,
       c.segmento, c.tier,
       COALESCE(d.valor, 0)                              AS devol_valor,
       CASE WHEN ch.chamado_id IS NULL THEN 0 ELSE 1 END AS tem_chamado,
       CASE WHEN ch.data_fechamento IS NOT NULL
            THEN julianday(ch.data_fechamento) - julianday(ch.data_abertura) END AS dias_resolucao
FROM pedidos p
JOIN clientes c USING (cliente_id)
LEFT JOIN devolucoes d USING (pedido_id)
LEFT JOIN chamados  ch USING (pedido_id);

-- Grão: mês x região x linha x segmento. Todo KPI do painel sai daqui (somas, nunca médias).
CREATE VIEW vw_cubo_mensal AS
SELECT ano_mes, regiao, linha, segmento,
       SUM(CASE WHEN status <> 'cancelado' THEN valor_liquido ELSE 0 END)                         AS receita,
       SUM(CASE WHEN status <> 'cancelado' THEN custo_total   ELSE 0 END)                         AS custo,
       SUM(CASE WHEN status <> 'cancelado' THEN valor_bruto   ELSE 0 END)                         AS bruto,
       SUM(CASE WHEN status <> 'cancelado' THEN 1 ELSE 0 END)                                     AS pedidos,
       COUNT(*)                                                                                   AS pedidos_total,
       SUM(CASE WHEN status = 'cancelado' THEN 1 ELSE 0 END)                                      AS cancelados,
       SUM(CASE WHEN status = 'entregue' THEN 1 ELSE 0 END)                                       AS entregues,
       SUM(CASE WHEN status = 'entregue' AND data_entrega <= data_prometida THEN 1 ELSE 0 END)    AS no_prazo,
       SUM(CASE WHEN status = 'entregue' THEN julianday(data_entrega) - julianday(data_pedido) ELSE 0 END)     AS leadtime_dias,
       SUM(CASE WHEN status = 'entregue' AND data_entrega > data_prometida
                THEN julianday(data_entrega) - julianday(data_prometida) ELSE 0 END)              AS atraso_dias,
       SUM(devol_valor)                                                                           AS devol_valor,
       SUM(tem_chamado)                                                                           AS chamados,
       SUM(CASE WHEN dias_resolucao IS NOT NULL THEN 1 ELSE 0 END)                                AS chamados_resolvidos,
       SUM(COALESCE(dias_resolucao, 0))                                                           AS resolucao_dias
FROM vw_pedidos
GROUP BY ano_mes, regiao, linha, segmento;

-- Clientes ativos (compraram no mês): distintos, por isso fora do cubo
CREATE VIEW vw_ativos_mensal AS
SELECT ano_mes, regiao, segmento, COUNT(DISTINCT cliente_id) AS ativos
FROM vw_pedidos WHERE status <> 'cancelado'
GROUP BY ano_mes, regiao, segmento;

-- KPIs globais por mês
CREATE VIEW vw_kpi_mensal AS
SELECT ano_mes,
       SUM(receita)                                         AS receita,
       100.0 * (1 - SUM(custo) / SUM(receita))              AS margem_pct,
       100.0 * (1 - SUM(receita) / SUM(bruto))              AS desconto_pct,
       SUM(pedidos)                                         AS pedidos,
       SUM(receita) / SUM(pedidos)                          AS ticket_medio,
       100.0 * SUM(no_prazo) / SUM(entregues)               AS otd_pct,
       100.0 * SUM(devol_valor) / SUM(receita)              AS devolucao_pct,
       100.0 * SUM(cancelados) / SUM(pedidos_total)         AS cancelamento_pct,
       SUM(resolucao_dias) / NULLIF(SUM(chamados_resolvidos), 0) AS resolucao_media_dias
FROM vw_cubo_mensal
GROUP BY ano_mes;

-- Realizado x orçado x forecast por mês, região e linha
CREATE VIEW vw_real_vs_plano AS
SELECT pl.ano_mes, pl.regiao, pl.linha,
       a.receita,
       pl.receita_orcada, pl.receita_forecast,
       100.0 * (a.receita / pl.receita_orcada - 1)          AS var_orcado_pct,
       100.0 * (a.receita / pl.receita_forecast - 1)        AS var_forecast_pct,
       100.0 * (1 - a.custo / a.receita)                    AS margem_pct,
       100.0 * pl.margem_orcada_pct                         AS margem_orcada_pct
FROM plano_mensal pl
JOIN (SELECT ano_mes, regiao, linha, SUM(receita) AS receita, SUM(custo) AS custo
      FROM vw_cubo_mensal GROUP BY 1, 2, 3) a USING (ano_mes, regiao, linha);

-- Resumo anual por região (tabela "Desempenho por região" do painel)
CREATE VIEW vw_kpi_regiao_ano AS
SELECT substr(ano_mes, 1, 4) AS ano, regiao,
       SUM(receita)                                         AS receita,
       SUM(receita_orcada)                                  AS receita_orcada,
       100.0 * (SUM(receita) / SUM(receita_orcada) - 1)     AS var_orcado_pct,
       SUM(receita_forecast)                                AS receita_forecast,
       100.0 * (SUM(receita) / SUM(receita_forecast) - 1)   AS var_forecast_pct
FROM vw_real_vs_plano
GROUP BY 1, 2;
