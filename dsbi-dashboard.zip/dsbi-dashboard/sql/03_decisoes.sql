/* =====================================================================
   03 - DO INDICADOR À DECISÃO
   Cada view abaixo mede UM sinal e usa os gatilhos da tabela `parametros`.
   O exportador (src/exportar_json.py) transforma cada sinal em um cartão de decisão:
   indicador, gatilho, evidência, hipóteses alternativas, ação, dono, prazo,
   impacto (observado ou estimado, com a premissa) e gatilho de revisão.
   ===================================================================== */
DROP VIEW IF EXISTS vw_clientes_risco;
DROP VIEW IF EXISTS vw_margem_linha;
DROP VIEW IF EXISTS vw_margem_lista_linha;
DROP VIEW IF EXISTS vw_otd_regiao;
DROP VIEW IF EXISTS vw_devolucao_atraso;
DROP VIEW IF EXISTS vw_ruptura;
DROP VIEW IF EXISTS vw_vendedor_desconto;
DROP VIEW IF EXISTS vw_concentracao_clientes;
DROP VIEW IF EXISTS vw_sazonalidade;

/* D1 - Clientes em risco: sem comprar há mais que max(90 dias, 3x o intervalo habitual) */
CREATE VIEW vw_clientes_risco AS
WITH a AS (
    SELECT p.cliente_id,
           COUNT(*)                AS pedidos_24m,
           MIN(p.data_pedido)      AS primeira,
           MAX(p.data_pedido)      AS ultima
    FROM pedidos p
    WHERE p.status <> 'cancelado'
      AND p.data_pedido > date((SELECT valor FROM parametros WHERE chave = 'as_of'), '-24 months')
    GROUP BY p.cliente_id
),
b AS (
    SELECT a.*,
           (julianday(ultima) - julianday(primeira)) / (pedidos_24m - 1)                     AS intervalo_medio,
           julianday((SELECT valor FROM parametros WHERE chave = 'as_of')) - julianday(ultima) AS dias_sem_compra,
           (SELECT SUM(x.valor_liquido) FROM pedidos x
             WHERE x.cliente_id = a.cliente_id AND x.status <> 'cancelado'
               AND x.data_pedido > date(a.ultima, '-12 months') AND x.data_pedido <= a.ultima) AS receita_12m_antes
    FROM a
    WHERE pedidos_24m >= (SELECT CAST(valor AS INTEGER) FROM parametros WHERE chave = 'risco_min_pedidos')
)
SELECT b.cliente_id, c.nome, c.segmento, c.tier, c.regiao, c.vendedor_id,
       v.nome AS vendedor, v.ativo AS vendedor_ativo,
       b.ultima AS ultima_compra, CAST(ROUND(b.dias_sem_compra) AS INTEGER) AS dias_sem_compra,
       ROUND(b.intervalo_medio, 1) AS intervalo_medio, b.pedidos_24m,
       ROUND(b.receita_12m_antes, 2) AS receita_12m_antes
FROM b
JOIN clientes c   USING (cliente_id)
JOIN vendedores v USING (vendedor_id)
WHERE b.dias_sem_compra > MAX((SELECT CAST(valor AS REAL) FROM parametros WHERE chave = 'risco_dias_min'),
                              (SELECT CAST(valor AS REAL) FROM parametros WHERE chave = 'risco_mult_intervalo') * b.intervalo_medio)
  AND b.dias_sem_compra <= (SELECT CAST(valor AS REAL) FROM parametros WHERE chave = 'risco_dias_max');

/* D2 - Margem e desconto por linha: últimos 6 meses x 6 meses anteriores */
CREATE VIEW vw_margem_linha AS
WITH j AS (
    SELECT strftime('%Y-%m', date(valor, '-6 months'))  AS m6,
           strftime('%Y-%m', date(valor, '-12 months')) AS m12
    FROM parametros WHERE chave = 'as_of'
)
SELECT p.linha,
       CASE WHEN p.ano_mes > j.m6 THEN 'atual' ELSE 'anterior' END AS janela,
       SUM(p.valor_liquido)                                        AS receita,
       COUNT(*)                                                    AS pedidos,
       100.0 * (1 - SUM(p.custo_total) / SUM(p.valor_liquido))     AS margem_pct,
       100.0 * (1 - SUM(p.valor_liquido) / SUM(p.valor_bruto))     AS desconto_pct,
       100.0 * (1 - SUM(p.custo_total) / SUM(p.valor_bruto))       AS margem_lista_pct   -- margem se não houvesse desconto
FROM vw_pedidos p, j
WHERE p.status <> 'cancelado' AND p.ano_mes > j.m12
GROUP BY p.linha, janela;

/* D3 - Entrega no prazo por região: últimos 3 meses x 3 meses anteriores */
CREATE VIEW vw_otd_regiao AS
WITH j AS (
    SELECT strftime('%Y-%m', date(valor, '-3 months')) AS m3,
           strftime('%Y-%m', date(valor, '-6 months')) AS m6
    FROM parametros WHERE chave = 'as_of'
)
SELECT p.regiao,
       CASE WHEN p.ano_mes > j.m3 THEN 'atual' ELSE 'anterior' END AS janela,
       COUNT(*)                                                                         AS entregues,
       100.0 * SUM(CASE WHEN p.data_entrega <= p.data_prometida THEN 1 ELSE 0 END) / COUNT(*) AS otd_pct,
       SUM(p.valor_liquido)                                                             AS receita
FROM vw_pedidos p, j
WHERE p.status = 'entregue' AND p.ano_mes > j.m6
GROUP BY p.regiao, janela;

/* D3b - O atraso custa algo? Devolução em pedidos atrasados x no prazo (últimos 6 meses, todas as regiões) */
CREATE VIEW vw_devolucao_atraso AS
WITH j AS (SELECT strftime('%Y-%m', date(valor, '-6 months')) AS m6 FROM parametros WHERE chave = 'as_of')
SELECT CASE WHEN p.data_entrega > p.data_prometida THEN 'atrasado' ELSE 'no_prazo' END AS grupo,
       COUNT(*)                                                              AS pedidos,
       SUM(CASE WHEN p.devol_valor > 0 THEN 1 ELSE 0 END)                    AS devolvidos,
       100.0 * SUM(CASE WHEN p.devol_valor > 0 THEN 1 ELSE 0 END) / COUNT(*) AS taxa_devolucao_pedidos,
       100.0 * SUM(p.devol_valor) / SUM(p.valor_liquido)                     AS devol_pct_receita,
       100.0 * SUM(CASE WHEN p.tem_chamado = 1 THEN 1 ELSE 0 END) / COUNT(*) AS taxa_chamado
FROM vw_pedidos p, j
WHERE p.status = 'entregue' AND p.ano_mes > j.m6
GROUP BY grupo;

/* D4 - Ruptura de estoque: dias sem produto no último trimestre x venda diária do semestre anterior ao trimestre */
CREATE VIEW vw_ruptura AS
WITH j AS (
    SELECT strftime('%Y-%m', date(valor, '-3 months')) AS m3,
           strftime('%Y-%m', date(valor, '-9 months')) AS m9
    FROM parametros WHERE chave = 'as_of'
),
rup AS (
    SELECT e.produto_id, SUM(e.ruptura_dias) AS ruptura_dias
    FROM estoque_mensal e, j WHERE e.ano_mes > j.m3 GROUP BY e.produto_id
),
base AS (
    SELECT i.produto_id, SUM(i.preco_unit * i.qtd) AS rec_base, SUM((i.preco_unit - i.custo_unit) * i.qtd) AS mg_base
    FROM pedido_itens i JOIN vw_pedidos p USING (pedido_id), j
    WHERE p.status <> 'cancelado' AND p.ano_mes > j.m9 AND p.ano_mes <= j.m3
    GROUP BY i.produto_id
),
atu AS (
    SELECT i.produto_id, SUM(i.preco_unit * i.qtd) AS rec_atual
    FROM pedido_itens i JOIN vw_pedidos p USING (pedido_id), j
    WHERE p.status <> 'cancelado' AND p.ano_mes > j.m3
    GROUP BY i.produto_id
)
SELECT pr.produto_id, pr.nome, pr.linha, rup.ruptura_dias,
       base.rec_base / 181.0                               AS rec_dia_base,     -- jan-jun = 181 dias
       base.mg_base / base.rec_base                        AS margem_unit_pct,
       COALESCE(atu.rec_atual, 0)                          AS rec_atual,
       base.rec_base / 181.0 * 92 - COALESCE(atu.rec_atual, 0) AS queda_observada,  -- jul-set = 92 dias
       base.rec_base / 181.0 * rup.ruptura_dias            AS perda_estimada
FROM rup
JOIN produtos pr USING (produto_id)
JOIN base USING (produto_id)
LEFT JOIN atu USING (produto_id);

/* D5 - Desconto por vendedor nos últimos 6 meses, em z-score contra os pares */
CREATE VIEW vw_vendedor_desconto AS
WITH j AS (SELECT strftime('%Y-%m', date(valor, '-6 months')) AS m6 FROM parametros WHERE chave = 'as_of'),
v AS (
    SELECT p.vendedor_id,
           SUM(p.valor_liquido)                                    AS receita,
           COUNT(*)                                                AS pedidos,
           SUM(p.valor_bruto)                                      AS bruto,
           100.0 * (1 - SUM(p.valor_liquido) / SUM(p.valor_bruto)) AS desconto_pct,
           100.0 * (1 - SUM(p.custo_total) / SUM(p.valor_liquido)) AS margem_pct
    FROM vw_pedidos p, j
    WHERE p.status <> 'cancelado' AND p.ano_mes > j.m6
    GROUP BY p.vendedor_id
),
s AS (
    SELECT AVG(desconto_pct) AS mu,
           sqrt(AVG(desconto_pct * desconto_pct) - AVG(desconto_pct) * AVG(desconto_pct)) AS sd
    FROM v
)
SELECT v.vendedor_id, vd.nome, vd.regiao, v.receita, v.pedidos, v.bruto, v.desconto_pct, v.margem_pct,
       (v.desconto_pct - s.mu) / s.sd AS z
FROM v CROSS JOIN s
JOIN vendedores vd USING (vendedor_id);

/* D6 - Concentração: participação dos maiores clientes na receita dos últimos 12 meses */
CREATE VIEW vw_concentracao_clientes AS
WITH j AS (SELECT date(valor, '-12 months') AS d0 FROM parametros WHERE chave = 'as_of'),
t AS (
    SELECT p.cliente_id, SUM(p.valor_liquido) AS receita
    FROM pedidos p, j WHERE p.status <> 'cancelado' AND p.data_pedido > j.d0
    GROUP BY p.cliente_id
),
r AS (
    SELECT t.*, ROW_NUMBER() OVER (ORDER BY receita DESC) AS rk, SUM(receita) OVER () AS total FROM t
)
SELECT r.cliente_id, c.nome, c.segmento, c.tier, c.regiao, r.receita, r.rk,
       100.0 * r.receita / r.total                                        AS pct,
       100.0 * SUM(r.receita) OVER (ORDER BY r.rk) / r.total              AS pct_acum
FROM r JOIN clientes c USING (cliente_id);

/* D7 - Sazonalidade: índice do mês (média do ano = 1), anos completos 2024-2025 */
CREATE VIEW vw_sazonalidade AS
WITH m AS (
    SELECT substr(ano_mes, 1, 4) AS ano, CAST(substr(ano_mes, 6, 2) AS INTEGER) AS mes, SUM(receita) AS rec
    FROM vw_cubo_mensal WHERE ano_mes < '2026-01' GROUP BY 1, 2
),
a AS (SELECT ano, AVG(rec) AS media FROM m GROUP BY ano)
SELECT m.mes, ROUND(AVG(m.rec / a.media), 3) AS indice
FROM m JOIN a USING (ano)
GROUP BY m.mes;
