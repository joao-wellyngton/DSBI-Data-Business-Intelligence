/* =====================================================================
   04 - QUALIDADE DOS DADOS
   severidade 'erro'  -> deve ser 0 (os testes falham se não for)
   severidade 'info'  -> comportamento esperado, documentado no painel
   ===================================================================== */
DROP VIEW IF EXISTS vw_qualidade;
CREATE VIEW vw_qualidade AS
SELECT 'Itens sem pedido' AS verificacao, 'erro' AS severidade,
       (SELECT COUNT(*) FROM pedido_itens WHERE pedido_id NOT IN (SELECT pedido_id FROM pedidos)) AS qtd
UNION ALL SELECT 'Pedidos sem itens', 'erro',
       (SELECT COUNT(*) FROM pedidos WHERE pedido_id NOT IN (SELECT pedido_id FROM pedido_itens))
UNION ALL SELECT 'Soma dos itens diferente do valor do pedido', 'erro',
       (SELECT COUNT(*) FROM pedidos p JOIN (SELECT pedido_id, SUM(qtd * preco_unit) AS s FROM pedido_itens GROUP BY 1) i USING (pedido_id)
         WHERE ABS(i.s - p.valor_liquido) > 0.05)
UNION ALL SELECT 'Entrega antes do pedido', 'erro',
       (SELECT COUNT(*) FROM pedidos WHERE data_entrega IS NOT NULL AND data_entrega < data_pedido)
UNION ALL SELECT 'Valores não positivos', 'erro',
       (SELECT COUNT(*) FROM pedidos WHERE valor_liquido <= 0 OR custo_total <= 0 OR valor_bruto <= 0)
UNION ALL SELECT 'Desconto acima do preço de lista', 'erro',
       (SELECT COUNT(*) FROM pedidos WHERE valor_liquido > valor_bruto + 0.05)
UNION ALL SELECT 'Cancelado com data de entrega', 'erro',
       (SELECT COUNT(*) FROM pedidos WHERE status = 'cancelado' AND data_entrega IS NOT NULL)
UNION ALL SELECT 'Entregue sem data de entrega', 'erro',
       (SELECT COUNT(*) FROM pedidos WHERE status = 'entregue' AND data_entrega IS NULL)
UNION ALL SELECT 'Devolução maior que o pedido', 'erro',
       (SELECT COUNT(*) FROM devolucoes d JOIN pedidos p USING (pedido_id) WHERE d.valor > p.valor_liquido + 0.05)
UNION ALL SELECT 'Pedido anterior ao cadastro do cliente', 'erro',
       (SELECT COUNT(*) FROM pedidos p JOIN clientes c USING (cliente_id) WHERE p.data_pedido < c.data_cadastro)
UNION ALL SELECT 'Pedidos em trânsito (sem entrega ainda)', 'info',
       (SELECT COUNT(*) FROM pedidos WHERE status = 'em_transito')
UNION ALL SELECT 'Pedidos cancelados', 'info',
       (SELECT COUNT(*) FROM pedidos WHERE status = 'cancelado')
UNION ALL SELECT 'Devoluções após a data de corte descartadas na origem', 'info', 0
UNION ALL SELECT 'Clientes sem nenhum pedido', 'info',
       (SELECT COUNT(*) FROM clientes WHERE cliente_id NOT IN (SELECT cliente_id FROM pedidos))
UNION ALL SELECT 'Vendedor inativo com carteira', 'info',
       (SELECT COUNT(DISTINCT c.cliente_id) FROM clientes c JOIN vendedores v USING (vendedor_id) WHERE v.ativo = 0);
