/* =====================================================================
   01 - SCHEMA (SQLite)
   Empresa fictícia "Vertix Distribuidora": clientes, vendedores, produtos, pedidos,
   devoluções, chamados, estoque, plano (orçamento/forecast) e parâmetros.
   ===================================================================== */
PRAGMA foreign_keys = ON;

CREATE TABLE regioes (
    regiao           TEXT PRIMARY KEY,
    prazo_base_dias  INTEGER NOT NULL
);

CREATE TABLE vendedores (
    vendedor_id  TEXT PRIMARY KEY,
    nome         TEXT NOT NULL,
    regiao       TEXT NOT NULL REFERENCES regioes(regiao),
    ativo        INTEGER NOT NULL CHECK (ativo IN (0, 1)),
    data_saida   TEXT
);

CREATE TABLE clientes (
    cliente_id     INTEGER PRIMARY KEY,
    nome           TEXT NOT NULL,
    segmento       TEXT NOT NULL CHECK (segmento IN ('Varejo', 'Atacado', 'Indústria', 'Serviços')),
    tier           TEXT NOT NULL CHECK (tier IN ('Ouro', 'Prata', 'Bronze')),
    regiao         TEXT NOT NULL REFERENCES regioes(regiao),
    uf             TEXT NOT NULL,
    vendedor_id    TEXT NOT NULL REFERENCES vendedores(vendedor_id),
    data_cadastro  TEXT NOT NULL
);

CREATE TABLE produtos (
    produto_id   INTEGER PRIMARY KEY,
    nome         TEXT NOT NULL,
    linha        TEXT NOT NULL,
    preco_lista  REAL NOT NULL CHECK (preco_lista > 0),
    custo_unit   REAL NOT NULL CHECK (custo_unit > 0)
);

CREATE TABLE pedidos (
    pedido_id       INTEGER PRIMARY KEY,
    cliente_id      INTEGER NOT NULL REFERENCES clientes(cliente_id),
    vendedor_id     TEXT NOT NULL REFERENCES vendedores(vendedor_id),
    regiao          TEXT NOT NULL REFERENCES regioes(regiao),
    linha           TEXT NOT NULL,                      -- cada pedido pertence a uma linha de produto
    canal           TEXT NOT NULL,
    data_pedido     TEXT NOT NULL,                      -- ISO yyyy-mm-dd
    data_prometida  TEXT NOT NULL,
    data_entrega    TEXT,                               -- NULL se cancelado ou em trânsito
    status          TEXT NOT NULL CHECK (status IN ('entregue', 'cancelado', 'em_transito')),
    valor_bruto     REAL NOT NULL,                      -- a preço de lista
    valor_liquido   REAL NOT NULL,                      -- depois do desconto
    custo_total     REAL NOT NULL
);

CREATE TABLE pedido_itens (
    pedido_id    INTEGER NOT NULL REFERENCES pedidos(pedido_id),
    produto_id   INTEGER NOT NULL REFERENCES produtos(produto_id),
    qtd          INTEGER NOT NULL CHECK (qtd > 0),
    preco_unit   REAL NOT NULL,
    desconto     REAL NOT NULL,
    custo_unit   REAL NOT NULL
);

CREATE TABLE devolucoes (
    pedido_id        INTEGER PRIMARY KEY REFERENCES pedidos(pedido_id),
    data_devolucao   TEXT NOT NULL,
    valor            REAL NOT NULL CHECK (valor >= 0),
    motivo           TEXT NOT NULL
);

CREATE TABLE chamados (
    chamado_id     INTEGER PRIMARY KEY,
    pedido_id      INTEGER NOT NULL UNIQUE REFERENCES pedidos(pedido_id),
    cliente_id     INTEGER NOT NULL REFERENCES clientes(cliente_id),
    categoria      TEXT NOT NULL,
    data_abertura  TEXT NOT NULL,
    data_fechamento TEXT
);

CREATE TABLE estoque_mensal (
    produto_id    INTEGER NOT NULL REFERENCES produtos(produto_id),
    ano_mes       TEXT NOT NULL,
    qtd_final     INTEGER NOT NULL,
    ruptura_dias  INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (produto_id, ano_mes)
);

CREATE TABLE plano_mensal (            -- orçamento (budget) e forecast por mês x região x linha
    ano_mes             TEXT NOT NULL,
    regiao              TEXT NOT NULL,
    linha               TEXT NOT NULL,
    receita_orcada      REAL NOT NULL,
    margem_orcada_pct   REAL NOT NULL,
    receita_forecast    REAL NOT NULL,
    PRIMARY KEY (ano_mes, regiao, linha)
);

CREATE TABLE parametros (               -- metas e gatilhos de decisão: mudar aqui muda as views
    chave      TEXT PRIMARY KEY,
    valor      TEXT NOT NULL,
    descricao  TEXT
);

CREATE INDEX ix_ped_data    ON pedidos (data_pedido);
CREATE INDEX ix_ped_cli     ON pedidos (cliente_id, data_pedido);
CREATE INDEX ix_ped_reg_lin ON pedidos (regiao, linha);
CREATE INDEX ix_item_ped    ON pedido_itens (pedido_id);
CREATE INDEX ix_item_prod   ON pedido_itens (produto_id);
